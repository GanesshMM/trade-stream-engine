// Karma configuration file
// https://karma-runner.github.io/6.4/config/configuration-file.html

try {
  // Use bundled Chromium so tests do not depend on local Chrome installation.
  const puppeteer = require('puppeteer');
  process.env.CHROME_BIN = puppeteer.executablePath();
} catch (e) {
  // Fallback to system Chrome if Puppeteer is not installed yet.
}

const path = require('path');
const fs = require('fs');
const { execSync } = require('child_process');
const edgeKarmaProfile = path.join(__dirname, '.karma-edge-profile');

const edgeCandidates = [
  'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  process.env.LOCALAPPDATA
    ? `${process.env.LOCALAPPDATA.replace(/\\/g, '/')}/Microsoft/Edge/Application/msedge.exe`
    : ''
];

let resolvedEdgeBin = edgeCandidates.find(p => !!p && fs.existsSync(p));
if (!resolvedEdgeBin) {
  try {
    const whereOut = execSync('where msedge', { stdio: ['ignore', 'pipe', 'ignore'] })
      .toString()
      .split(/\r?\n/)
      .map(line => line.trim())
      .find(line => !!line && fs.existsSync(line));
    if (whereOut) {
      resolvedEdgeBin = whereOut.replace(/\\/g, '/');
    }
  } catch {
    // Keep fallback behavior below when Edge binary isn't found.
  }
}

if (resolvedEdgeBin) {
  process.env.CHROME_BIN = resolvedEdgeBin;
}

module.exports = function (config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine', '@angular-devkit/build-angular'],
    plugins: [
      require('karma-jasmine'),
      require('karma-chrome-launcher'),
      require('karma-jasmine-html-reporter'),
      require('karma-coverage'),
      require('@angular-devkit/build-angular/plugins/karma')
    ],
    client: {
      jasmine: {
        // Customize Jasmine options if needed
      },
      clearContext: false
    },
    jasmineHtmlReporter: {
      suppressAll: true
    },
    coverageReporter: {
      dir: path.join(__dirname, './coverage/trade-ui'),
      subdir: '.',
      reporters: [
        { type: 'html' },
        { type: 'text-summary' }
      ]
    },
    reporters: ['progress', 'kjhtml'],
    port: 9876,
    colors: true,
    logLevel: config.LOG_INFO,
  captureTimeout: 120000,
  browserNoActivityTimeout: 120000,
  browserDisconnectTimeout: 30000,
  browserDisconnectTolerance: 2,
    autoWatch: true,
    customLaunchers: {
      ChromeHeadlessCI: {
        base: 'ChromeHeadless',
        flags: ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage']
      },
      EdgeCI: {
        base: 'Chrome',
        binary: resolvedEdgeBin || process.env.CHROME_BIN,
        flags: [
          '--no-first-run',
          '--no-default-browser-check',
          '--disable-extensions'
        ]
      },
      EdgeHeadlessCI: {
        // Launch Chromium-based Edge through Chrome launcher to avoid legacy Edge process issues.
        base: 'ChromeHeadless',
        binary: resolvedEdgeBin || process.env.CHROME_BIN,
        flags: [
          '--headless',
          '--no-sandbox',
          '--disable-gpu',
          '--disable-dev-shm-usage',
          '--no-first-run',
          '--no-default-browser-check',
          '--disable-extensions',
          `--user-data-dir=${edgeKarmaProfile}`,
          '--remote-debugging-port=0'
        ]
      }
    },
    browsers: ['EdgeHeadlessCI'],
    singleRun: false,
    restartOnFileChange: true
  });
};
