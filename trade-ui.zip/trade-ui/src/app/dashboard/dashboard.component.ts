import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FileService } from '../shared/services/file.service';
import { DashboardStats, DashboardMetricsResponse, FileLoad } from '../shared/models/models';
import { forkJoin, map, Observable } from 'rxjs';
import { ConfirmDialogComponent } from '../shared/components/confirm-dialog.component';
import { Chart } from 'chart.js/auto';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  @ViewChild('fileInput') fileInputRef!: ElementRef<HTMLInputElement>;
  @ViewChild('qualityChart') qualityChartRef?: ElementRef<HTMLCanvasElement>;
  @ViewChild('statusChart') statusChartRef?: ElementRef<HTMLCanvasElement>;
  private readonly uiDemoMode = false;
  private viewInitialized = false;
  private qualityChart: Chart | null = null;
  private statusChart: Chart | null = null;
  private allDashboardFiles: FileLoad[] = [];

  metrics: DashboardMetricsResponse | null = null;
  stats: DashboardStats | null = null;
  latestFiles: FileLoad[] = [];
  archivedFilesCount = 0;
  loading = false;
  uploading = false;

  constructor(
    private fileService: FileService,
    private router: Router,
    private snackBar: MatSnackBar,
    private dialog: MatDialog
  ) {}

  ngAfterViewInit(): void {
    this.viewInitialized = true;
    this.renderCharts();
  }

  ngOnDestroy(): void {
    this.destroyCharts();
  }

  ngOnInit(): void {
    if (this.uiDemoMode) {
      this.loadMockDashboard();
      return;
    }

    // Load available backend records on initial dashboard open.
    this.loadDashboard();
  }

  get latestUploadedFileName(): string {
    return this.latestFiles?.[0]?.filename || '';
  }

  get hasLatestUploadData(): boolean {
    return !!this.latestFiles?.[0]?.uploadTime;
  }

  get latestUploadTimeLabel(): string {
    const latestUploadTime = this.latestFiles?.[0]?.uploadTime;
    if (!latestUploadTime) {
      return '';
    }

    const uploadedAt = new Date(latestUploadTime);
    if (Number.isNaN(uploadedAt.getTime())) {
      return '';
    }

    return this.formatUploadTime(uploadedAt);
  }

  loadDashboard(): void {
    this.loading = true;
    this.loadMetrics();

    const archivedParams = {
      status: 'ARCHIVED'
    };

    forkJoin({
      all: this.fileService.searchFiles({}),
      archived: this.fileService.searchFiles(archivedParams)
    }).subscribe({
      next: ({ all, archived }) => {
        const allFiles = this.extractFileList(all);
        const archivedFiles = this.extractFileList(archived);
        this.allDashboardFiles = allFiles;

        if (!this.metrics) {
          this.metrics = {
            totalFiles: allFiles.length,
            successRecords: allFiles.reduce((sum, f) => sum + (f.successCount || 0), 0),
            errorRecords: allFiles.reduce((sum, f) => sum + (f.errorCount || 0), 0)
          };
        }

        this.latestFiles = allFiles
          .sort((a, b) => new Date(b.uploadTime).getTime() - new Date(a.uploadTime).getTime())
          .slice(0, 6);

        this.stats = this.buildStatsFromFiles(allFiles, allFiles.length);
        this.archivedFilesCount = archivedFiles.length;
        this.renderCharts();
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.stats = null;
        this.latestFiles = [];
        this.allDashboardFiles = [];
        this.archivedFilesCount = 0;
        this.renderCharts();
        this.showErrorToast('Failed to load dashboard data');
      }
    });
  }

  private loadMetrics(): void {
    this.fileService.getMetrics().subscribe({
      next: (res) => {
        this.metrics = res?.data || null;
        this.renderCharts();
      },
      error: () => {
        this.metrics = null;
        this.renderCharts();
      }
    });
  }

  private buildStatsFromFiles(files: FileLoad[], totalFilesProcessed: number): DashboardStats {
    const completedFiles = files.filter(f => (f.status || '').toUpperCase() === 'COMPLETED').length;
    const failedFiles = files.filter(f => (f.status || '').toUpperCase() === 'FAILED').length;
    const filesWithErrors = files.filter(f => (f.status || '').toUpperCase() === 'COMPLETED_WITH_ERROR').length;

    const totalTransactions = files.reduce((sum, f) => sum + (f.totalRecords || 0), 0);
    const totalErrors = files.reduce((sum, f) => sum + (f.errorCount || 0), 0);

    return {
      totalFilesProcessed,
      completedFiles,
      failedFiles,
      filesWithErrors,
      totalTransactions,
      totalErrors
    };
  }

  loadArchivedFilesCount(): void {
    const params = {
      status: 'ARCHIVED'
    };

    this.fileService.searchFiles(params).subscribe({
      next: (res: any) => {
        this.archivedFilesCount = this.extractFileList(res).length;
      },
      error: () => {
        this.archivedFilesCount = 0;
      }
    });
  }

  onFileUpload(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    if (this.uiDemoMode) {
      this.uploading = true;

      setTimeout(() => {
        this.uploading = false;

        const now = new Date().toISOString();
        const newFile: FileLoad = {
          fileId: this.generateNextMockFileId(),
          filename: file.name,
          uploadTime: now,
          totalRecords: this.randomBetween(800, 3500),
          successCount: this.randomBetween(700, 3300),
          errorCount: this.randomBetween(0, 120),
          status: 'PROCESSING'
        };

        this.latestFiles = [newFile, ...this.latestFiles].slice(0, 6);
        this.stats = {
          totalFilesProcessed: (this.stats?.totalFilesProcessed || 0) + 1,
          completedFiles: this.stats?.completedFiles || 0,
          failedFiles: this.stats?.failedFiles || 0,
          filesWithErrors: this.stats?.filesWithErrors || 0,
          totalTransactions: (this.stats?.totalTransactions || 0) + newFile.totalRecords,
          totalErrors: (this.stats?.totalErrors || 0) + newFile.errorCount
        };

  this.showSuccessToast(`File uploaded successfully: ${file.name}`);
        input.value = '';
      }, 650);

      return;
    }

    this.uploading = true;

    this.fileService.uploadFile(file).subscribe({
      next: (res: any) => {
        const uploadedId = res?.data?.fileId;
        const uploadedName = res?.data?.fileName || file.name;
        const uploadedStatus = res?.data?.status || 'PROCESSING';

        const optimisticFile: FileLoad = {
          fileId: uploadedId || this.generateNextMockFileId(),
          filename: uploadedName,
          uploadTime: new Date().toISOString(),
          totalRecords: 0,
          successCount: 0,
          errorCount: 0,
          status: uploadedStatus
        };

        this.upsertLatestFile(optimisticFile);
        this.recalculateStatsFromLatest();

        if (uploadedId) {
          this.syncFileStatusFromBackend(uploadedId, uploadedName);
        } else {
          this.refreshLatestFilesFromBackend();
        }

        this.showSuccessToast(`File uploaded successfully: ${file.name}`);
        this.uploading = false;
        input.value = '';
      },
      error: (err: any) => {
  const message = err?.error?.message || 'Upload failed';
  this.showErrorToast(message);
        this.uploading = false;
        input.value = '';
      }
    });
  }

  private syncFileStatusFromBackend(fileId: number, fileName?: string, attempt: number = 0): void {
    const maxAttempts = 120;
    const retryDelayMs = 2500;

    this.fetchActiveFiles().subscribe({
      next: (activeFiles) => {
        const match = activeFiles.find(f => f.fileId === fileId)
          || activeFiles.find(f => fileName && f.filename === fileName)
          || null;

        if (match) {
          this.upsertLatestFile(match);
          this.recalculateStatsFromLatest();

          if (attempt < maxAttempts) {
            setTimeout(() => this.syncFileStatusFromBackend(fileId, fileName, attempt + 1), retryDelayMs);
          }
          return;
        }

        
        this.refreshLatestFilesFromBackend();
      },
      error: () => {
        if (attempt < maxAttempts) {
          setTimeout(() => this.syncFileStatusFromBackend(fileId, fileName, attempt + 1), retryDelayMs);
        }
      }
    });
  }

  private refreshLatestFilesFromBackend(): void {
    setTimeout(() => {
      this.fileService.searchFiles({
        page: 0,
        size: 6,
        sortBy: 'uploadTime',
        sortDir: 'desc'
      }).subscribe({
        next: (res: any) => {
          const allFiles = this.extractFileList(res);
          this.latestFiles = allFiles
            .sort((a, b) => new Date(b.uploadTime).getTime() - new Date(a.uploadTime).getTime())
            .slice(0, 6);
          this.allDashboardFiles = allFiles;
          this.recalculateStatsFromLatest();
          this.loadMetrics();
          this.renderCharts();
        }
      });
    }, 1500);
  }

  private fetchActiveFiles(): Observable<FileLoad[]> {
    const baseParams = {
      page: 0,
      size: 50,
      sortBy: 'uploadTime',
      sortDir: 'desc'
    };

    return forkJoin({
      started: this.fileService.searchFiles({ ...baseParams, status: 'STARTED' }),
      processing: this.fileService.searchFiles({ ...baseParams, status: 'PROCESSING' })
    }).pipe(
      map(({ started, processing }) => {
        const merged = [
          ...this.extractFileList(started),
          ...this.extractFileList(processing)
        ];

        const dedup = new Map<string, FileLoad>();
        merged.forEach(file => {
          const key = `${file.fileId}-${file.filename}`;
          dedup.set(key, file);
        });

        return Array.from(dedup.values());
      })
    );
  }
  
  private upsertLatestFile(file: FileLoad): void {
    const idx = this.latestFiles.findIndex(f => f.fileId === file.fileId);
    if (idx > -1) {
      this.latestFiles[idx] = file;
    } else {
      this.latestFiles = [file, ...this.latestFiles];
    }

    this.latestFiles = this.latestFiles
      .sort((a, b) => new Date(b.uploadTime).getTime() - new Date(a.uploadTime).getTime())
      .slice(0, 6);

    this.renderCharts();
  }

  private recalculateStatsFromLatest(): void {
    const files = this.latestFiles;

    this.stats = {
      totalFilesProcessed: files.length,
      completedFiles: files.filter(f => (f.status || '').toUpperCase() === 'COMPLETED').length,
      failedFiles: files.filter(f => (f.status || '').toUpperCase() === 'FAILED').length,
      filesWithErrors: files.filter(f => (f.status || '').toUpperCase() === 'COMPLETED_WITH_ERROR').length,
      totalTransactions: files.reduce((sum, f) => sum + (f.totalRecords || 0), 0),
      totalErrors: files.reduce((sum, f) => sum + (f.errorCount || 0), 0)
    };

    this.renderCharts();
  }

  private isTerminalStatus(status: string): boolean {
    const s = (status || '').toUpperCase();
    return s === 'COMPLETED' || s === 'FAILED' || s === 'COMPLETED_WITH_ERROR' || s === 'ARCHIVED' || s === 'DELETED';
  }

  private extractFileList(response: any): FileLoad[] {
    const data = response?.data;
    if (Array.isArray(data)) {
      return data;
    }
    if (Array.isArray(data?.content)) {
      return data.content;
    }
    return [];
  }

  triggerFilePicker(): void {
    if (!this.fileInputRef) return;
    
    this.fileInputRef.nativeElement.value = '';
    this.fileInputRef.nativeElement.click();
  }

  goToFiles(): void {
    this.router.navigate(['/files']);
  }

  goToErrors(): void {
    this.router.navigate(['/errors']);
  }

  openFileManagement(): void {
    this.router.navigate(['/files']);
  }

  openFileDetails(fileId: number): void {
    this.router.navigate(['/files', fileId]);
  }

  archive(fileId: number): void {
    this.confirmAction('Archive File', 'Are you sure you want to archive this file?', 'Archive')
      .subscribe(confirmed => {
        if (!confirmed) return;

        if (this.uiDemoMode) {
          this.latestFiles = this.latestFiles.map(f => f.fileId === fileId ? { ...f, status: 'ARCHIVED' } : f);
          this.archivedFilesCount += 1;
          this.showSuccessToast('File archived');
          return;
        }

        this.fileService.archiveFile(fileId).subscribe({
          next: () => {
            this.showSuccessToast('File archived');
            this.loadDashboard();
          },
          error: () => this.showErrorToast('Archive failed')
        });
      });
  }

  delete(fileId: number): void {
    this.confirmAction('Delete File', 'Are you sure you want to delete this file?', 'Delete')
      .subscribe(confirmed => {
        if (!confirmed) return;

        if (this.uiDemoMode) {
          this.latestFiles = this.latestFiles.filter(f => f.fileId !== fileId);
          this.showSuccessToast('File deleted');
          return;
        }

        this.fileService.deleteFile(fileId).subscribe({
          next: () => {
            this.showSuccessToast('File deleted');
            this.loadDashboard();
          },
          error: () => this.showErrorToast('Delete failed')
        });
      });
  }

  private confirmAction(title: string, message: string, confirmText: string) {
    return this.dialog.open(ConfirmDialogComponent, {
      width: '420px',
      disableClose: true,
      data: {
        title,
        message,
        confirmText,
        cancelText: 'Cancel'
      }
    }).afterClosed();
  }

  getStatusClass(status: string): string {
    switch ((status || '').toUpperCase()) {
      case 'COMPLETED':
        return 'status-processed';
      case 'PROCESSING':
      case 'STARTED':
        return 'status-processing';
      case 'FAILED':
      case 'COMPLETED_WITH_ERROR':
        return 'status-failed';
      case 'ARCHIVED':
        return 'status-archived';
      default:
        return 'status-processing';
    }
  }

  getStatusText(status: string): string {
    const normalized = (status || 'UNKNOWN').toUpperCase();
    return normalized === 'COMPLETED_WITH_ERROR' ? 'PARTIALLY_COMPLETED' : normalized;
  }

  formatFileId(id: number): string {
    const year = new Date().getFullYear();
    return `FL-${year}-${String(id).padStart(5, '0')}`;
  }

  formatNumber(value: number): string {
    return value.toLocaleString('en-US');
  }

  private formatUploadTime(date: Date): string {
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  }

  private showSuccessToast(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 2600,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-success']
    });
  }

  private showErrorToast(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  }

  private loadMockDashboard(): void {
    this.loading = false;
    this.stats = {
      totalFilesProcessed: 47,
      completedFiles: 31,
      failedFiles: 5,
      filesWithErrors: 11,
      totalTransactions: 12458,
      totalErrors: 342
    };
    this.metrics = {
      totalFiles: 47,
      successRecords: 12458,
      errorRecords: 342
    };
    this.archivedFilesCount = 128;
    this.latestFiles = [
      {
        fileId: 234,
        filename: 'trade_data_20260314_batch01.csv',
        uploadTime: '2026-03-14T09:23:15',
        totalRecords: 2845,
        successCount: 2810,
        errorCount: 35,
        status: 'COMPLETED'
      },
      {
        fileId: 233,
        filename: 'equity_trades_morning_session.csv',
        uploadTime: '2026-03-14T08:15:42',
        totalRecords: 1523,
        successCount: 1498,
        errorCount: 25,
        status: 'PROCESSING'
      },
      {
        fileId: 232,
        filename: 'options_settlement_data.csv',
        uploadTime: '2026-03-14T07:45:30',
        totalRecords: 856,
        successCount: 702,
        errorCount: 154,
        status: 'FAILED'
      },
      {
        fileId: 231,
        filename: 'fx_trades_overnight.csv',
        uploadTime: '2026-03-14T06:30:18',
        totalRecords: 3421,
        successCount: 3400,
        errorCount: 21,
        status: 'COMPLETED'
      },
      {
        fileId: 230,
        filename: 'bond_transactions_q1.csv',
        uploadTime: '2026-03-14T05:12:05',
        totalRecords: 1987,
        successCount: 1987,
        errorCount: 0,
        status: 'ARCHIVED'
      }
    ];

    this.allDashboardFiles = [...this.latestFiles];
    this.renderCharts();
  }

  private generateNextMockFileId(): number {
    const maxId = this.latestFiles.reduce((max, f) => Math.max(max, f.fileId), 200);
    return maxId + 1;
  }

  private randomBetween(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  private renderCharts(): void {
    if (!this.viewInitialized || !this.qualityChartRef || !this.statusChartRef) {
      return;
    }

    this.renderQualityChart();
    this.renderStatusChart();
  }

  private renderQualityChart(): void {
    const canvas = this.qualityChartRef?.nativeElement;
    if (!canvas) return;

    const success = this.metrics?.successRecords
      ?? this.allDashboardFiles.reduce((sum, file) => sum + (file.successCount || 0), 0);
    const errors = this.metrics?.errorRecords
      ?? this.allDashboardFiles.reduce((sum, file) => sum + (file.errorCount || 0), 0);

    const hasData = success > 0 || errors > 0;
    const labels = hasData ? ['Successful Records', 'Error Records'] : ['No Records'];
    const values = hasData ? [success, errors] : [1];
    const colors = hasData ? ['#1fa955', '#de3040'] : ['#b0bec5'];

    this.qualityChart?.destroy();
    this.qualityChart = new Chart(canvas, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [
          {
            data: values,
            backgroundColor: colors,
            borderWidth: 0,
            hoverOffset: 4
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '66%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              boxWidth: 10,
              boxHeight: 10,
              usePointStyle: true,
              pointStyle: 'circle'
            }
          }
        }
      }
    });
  }

  private renderStatusChart(): void {
    const canvas = this.statusChartRef?.nativeElement;
    if (!canvas) return;

    const statusKeys = ['COMPLETED', 'PARTIALLY_COMPLETED', 'FAILED', 'PROCESSING', 'ARCHIVED'];
    const labelMap: Record<string, string> = {
      COMPLETED: 'Completed',
      PARTIALLY_COMPLETED: 'Partially Completed',
      FAILED: 'Failed',
      PROCESSING: 'Processing',
      ARCHIVED: 'Archived'
    };
    const counts = new Map<string, number>(statusKeys.map(key => [key, 0]));

    this.allDashboardFiles.forEach(file => {
      const normalized = this.getStatusText(file.status);
      if (counts.has(normalized)) {
        counts.set(normalized, (counts.get(normalized) || 0) + 1);
      }
    });

    const hasData = Array.from(counts.values()).some(v => v > 0);
  const labels = hasData ? statusKeys.map(key => labelMap[key]) : ['No Data'];
  const values = hasData ? statusKeys.map(key => counts.get(key) || 0) : [0];
    const colors = hasData
      ? ['#1fa955', '#f59e0b', '#de3040', '#3b6ce0', '#5f6f83']
      : ['#b0bec5'];

    this.statusChart?.destroy();
    this.statusChart = new Chart(canvas, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label: 'Files',
            data: values,
            backgroundColor: colors,
            borderRadius: 6,
            maxBarThickness: 34
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          x: {
            grid: {
              display: false
            },
            ticks: {
              minRotation: 0,
              maxRotation: 0,
              autoSkip: false,
              callback: function (this: any, value: string | number) {
                const label = String(this.getLabelForValue(value as number) || '');
                if (label.length > 14 && label.includes(' ')) {
                  return label.split(' ');
                }
                return label;
              },
              font: {
                size: 10
              },
              padding: 8
            }
          },
          y: {
            beginAtZero: true,
            ticks: {
              precision: 0,
              font: {
                size: 11
              }
            },
            grid: {
              color: '#eef2f7'
            }
          }
        }
      }
    });
  }

  private destroyCharts(): void {
    this.qualityChart?.destroy();
    this.statusChart?.destroy();
    this.qualityChart = null;
    this.statusChart = null;
  }
}
