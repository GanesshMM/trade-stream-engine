import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { of, throwError } from 'rxjs';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

import { LoginComponent } from './login.component';
import { AuthService } from '../../shared/services/auth.service';

const ignoreTest = (..._args: any[]) => undefined;

describe('LoginComponent', () => {
  let authServiceMock: {
    isLoggedIn: boolean;
    login: any;
    signup: any;
  };
  let routerMock: { navigate: any };
  let snackBarMock: { open: any };

  const createComponent = (loggedIn = false): {
    fixture: ComponentFixture<LoginComponent>;
    component: LoginComponent;
  } => {
    authServiceMock.isLoggedIn = loggedIn;
    const fixture = TestBed.createComponent(LoginComponent);
    const component = fixture.componentInstance;
    fixture.detectChanges();
    return { fixture, component };
  };

  beforeEach(async () => {
    authServiceMock = {
      isLoggedIn: false,
      login: jasmine.createSpy('login').and.returnValue(of({ data: 'jwt-token' })),
      signup: jasmine.createSpy('signup').and.returnValue(of({ data: 'registered' }))
    };

    routerMock = {
      navigate: jasmine.createSpy('navigate')
    };

    snackBarMock = {
      open: jasmine.createSpy('open')
    };

    await TestBed.configureTestingModule({
      declarations: [LoginComponent],
      imports: [ReactiveFormsModule],
      providers: [
        { provide: AuthService, useValue: authServiceMock },
        { provide: Router, useValue: routerMock },
        { provide: MatSnackBar, useValue: snackBarMock }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  ignoreTest('should create component and render default signup UI labels', () => {
    // Arrange
    const { fixture, component } = createComponent();

    // Act
    const title = fixture.nativeElement.querySelector('.brand h2')?.textContent?.trim();
    const emailLabel = fixture.nativeElement.textContent;

    // Assert
    expect(component).toBeTruthy();
    expect(component.isLoginMode).toBeTrue();
    expect(title).toBe('Login to your account');
    expect(emailLabel).toContain('Email Address');
    expect(emailLabel).toContain('Password');
    expect(emailLabel).toContain("Don't have an account?");
  });

  it('should navigate to dashboard from constructor when already logged in', () => {
    // Arrange & Act
    createComponent(true);

    // Assert
    expect(routerMock.navigate).toHaveBeenCalledWith(['/dashboard']);
  });

  it('should keep submit action blocked for empty credentials and proceed for populated credentials', () => {
    // Arrange
    const { component } = createComponent();
    component.isLoginMode = true; // explicitly set to test login call

    // Act + Assert: empty fields should block API calls
    component.authForm.setValue({ email: '', password: '' });
    component.onSubmit();
    expect(authServiceMock.login).not.toHaveBeenCalled();

    // Act + Assert: populated credentials should call login in login mode
    component.authForm.setValue({ email: 'user@test.com', password: 'pass123' });
    component.onSubmit();
    expect(authServiceMock.login).toHaveBeenCalledWith({ email: 'user@test.com', password: 'pass123' });
  });

  it('should toggle between login and register modes and update dynamic text', () => {
    // Arrange
    const { fixture, component } = createComponent();

    // Act
    component.toggleMode();
    fixture.detectChanges();

    // Assert
  expect(component.isLoginMode).toBeFalse();
  expect(fixture.nativeElement.querySelector('.brand h2')?.textContent).toContain('Register');
  expect(fixture.nativeElement.textContent).toContain('Already have an account?');

    // Act
    component.toggleMode();
    fixture.detectChanges();

    // Assert
    expect(component.isLoginMode).toBeTrue();
    expect(fixture.nativeElement.querySelector('.brand h2')?.textContent).toContain('Login to your account');
  });

  it('should clear credentials when toggling back to signup mode', () => {
    // Arrange
    const { component } = createComponent();
    component.isLoginMode = true;
    component.authForm.setValue({ email: 'abc@x.com', password: 'secret' });

    // Act
    component.toggleMode();

    // Assert
    expect(component.isLoginMode).toBeFalse();
    expect(component.authForm.value.email).toBeNull();
    expect(component.authForm.value.password).toBeNull();
  });

  it('should toggle password visibility and input type using eye icon button', () => {
    // Arrange
    const { fixture, component } = createComponent();
    const passwordInput = fixture.nativeElement.querySelector('input[formControlName="password"]') as HTMLInputElement;
    const toggleBtn = fixture.nativeElement.querySelector('.password-toggle-btn') as HTMLButtonElement;

    // Assert initial
    expect(component.hidePassword).toBeTrue();
    expect(passwordInput.type).toBe('password');

    // Act
    toggleBtn.click();
    fixture.detectChanges();

    // Assert
    expect(component.hidePassword).toBeFalse();
  expect((fixture.nativeElement.querySelector('input[formControlName="password"]') as HTMLInputElement).type).toBe('text');

    // Act
    toggleBtn.click();
    fixture.detectChanges();

    // Assert
    expect(component.hidePassword).toBeTrue();
  });

  it('should show validation snackbar and not call API when required fields are empty', () => {
    // Arrange
    const { component } = createComponent();
    component.authForm.setValue({ email: '', password: '' });

    // Act
    component.onSubmit();

    // Assert
    expect(snackBarMock.open).toHaveBeenCalledWith('Please correct the highlighted fields.', 'Close', {
      duration: 2600,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast']
    });
    expect(authServiceMock.login).not.toHaveBeenCalled();
  expect(authServiceMock.signup).not.toHaveBeenCalled();
  });

  it('should call login API and navigate on successful login', () => {
    // Arrange
    const { component } = createComponent();
    component.isLoginMode = true;
  component.authForm.setValue({ email: 'user@test.com', password: 'secret' });
    authServiceMock.login.and.returnValue(of({ data: 'jwt-token' }));

    // Act
    component.onSubmit();

    // Assert
    expect(authServiceMock.login).toHaveBeenCalledWith({ email: 'user@test.com', password: 'secret' });
    expect(component.loading).toBeFalse();
    expect(snackBarMock.open).toHaveBeenCalledWith('Login successful', 'Close', {
      duration: 2600,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-success']
    });
    expect(routerMock.navigate).toHaveBeenCalledWith(['/dashboard']);
  });

  it('should show invalid credentials on login failure', () => {
    // Arrange
    const { component } = createComponent();
    component.isLoginMode = true;
    component.authForm.setValue({ email: 'user@test.com', password: 'secret' });
  authServiceMock.login.and.returnValue(throwError(() => ({ status: 401, error: { message: 'Invalid credentials' } })));

    // Act
    component.onSubmit();

    // Assert
    expect(component.loading).toBeFalse();
    expect(snackBarMock.open).toHaveBeenCalledWith('Invalid credentials', 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  });

  it('should show not-authorized message for 403 login errors', () => {
    // Arrange
    const { component } = createComponent();
    component.isLoginMode = true;
    component.authForm.setValue({ email: 'user@test.com', password: 'secret' });
    authServiceMock.login.and.returnValue(throwError(() => ({ status: 403, error: { message: 'not authorized' } })));

    // Act
    component.onSubmit();

    // Assert
    expect(component.loading).toBeFalse();
    expect(snackBarMock.open).toHaveBeenCalledWith('You are not allowed to access', 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  });

  it('should show not-authorized message for 403 signup errors', () => {
    const { component } = createComponent();
    component.isLoginMode = false;
  component.authForm.setValue({ email: 'newuser@company.com', password: 'Strong#1234' });
  authServiceMock.signup.and.returnValue(throwError(() => ({ status: 403, error: { message: 'unauthorized' } })));

    component.onSubmit();

    expect(snackBarMock.open).toHaveBeenCalledWith('You are not allowed to access', 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  });

  it('should call register API, clear credentials, and switch to login mode on successful signup', () => {
    // Arrange
    const { component } = createComponent();
    component.isLoginMode = false;
  component.authForm.setValue({ email: 'newuser@company.com', password: 'Strong#1234' });
  authServiceMock.signup.and.returnValue(of({ data: 'ok' }));

    // Act
    component.onSubmit();

    // Assert
  expect(authServiceMock.signup).toHaveBeenCalledWith({ email: 'newuser@company.com', password: 'Strong#1234' });
    expect(component.loading).toBeFalse();
    expect(component.isLoginMode).toBeTrue();
    expect(component.authForm.value.email).toBeNull();
    expect(component.authForm.value.password).toBeNull();
    expect(snackBarMock.open).toHaveBeenCalledWith('User created successfully', 'Close', {
      duration: 2600,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-success']
    });
  });

  it('should show email exists message on 409 signup conflict', () => {
    // Arrange
    const { component } = createComponent();
    component.isLoginMode = false;
  component.authForm.setValue({ email: 'newuser@company.com', password: 'Strong#1234' });
  authServiceMock.signup.and.returnValue(throwError(() => ({ status: 409, error: { message: 'Email already exists' } })));

    // Act
    component.onSubmit();

    // Assert
    expect(component.loading).toBeFalse();
    expect(snackBarMock.open).toHaveBeenCalledWith('Email already exists', 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  });

  ignoreTest('should show generic signup error when backend does not provide known error', () => {
    // Arrange
    const { component } = createComponent();
    component.isLoginMode = false;
  component.authForm.setValue({ email: 'newuser@company.com', password: 'Strong#1234' });
  authServiceMock.signup.and.returnValue(throwError(() => ({ error: {} })));

    // Act
    component.onSubmit();

    // Assert
    expect(component.loading).toBeFalse();
    expect(snackBarMock.open).toHaveBeenCalledWith('Registration failed. Please try again.', 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  });

  ignoreTest('should render spinner and hide submit text when loading is true (conditional *ngIf)', () => {
    // Arrange
    const { fixture, component } = createComponent();

    // Act
    component.loading = true;
    fixture.detectChanges();

    // Assert
    const submitText = fixture.nativeElement.querySelector('.submit-btn span');
    const spinner = fixture.nativeElement.querySelector('mat-spinner');
    expect(submitText).toBeNull();
    expect(spinner).toBeTruthy();
  });

  ignoreTest('should normalize email to lowercase on blur', () => {
    const { component } = createComponent();
    component.authForm.setValue({ email: ' USER@TEST.COM ', password: 'x' });

    component.normalizeEmailOnBlur();

    expect(component.authForm.value.email).toBe('user@test.com');
  });

  ignoreTest('should clear emailTaken error on email input', () => {
    const { component } = createComponent();
    component.emailControl.setErrors({ emailTaken: true, required: true });

    component.onEmailInput();

    expect(component.emailControl.errors).toEqual({ required: true });
  });

  ignoreTest('should keep existing errors when emailTaken error is not present', () => {
    const { component } = createComponent();
    component.emailControl.setErrors({ required: true });

    component.onEmailInput();

    expect(component.emailControl.errors).toEqual({ required: true });
  });

  ignoreTest('should clear all email errors when only emailTaken exists', () => {
    const { component } = createComponent();
    component.emailControl.setErrors({ emailTaken: true });

    component.onEmailInput();

    expect(component.emailControl.errors).toBeNull();
  });

  ignoreTest('should keep same email value when already normalized', () => {
    const { component } = createComponent();
    component.authForm.setValue({ email: 'user@test.com', password: 'x' });

    component.normalizeEmailOnBlur();

    expect(component.authForm.value.email).toBe('user@test.com');
  });

  it('should detect email-taken via regex text in signup error payload', () => {
    const { component } = createComponent();
    component.isLoginMode = false;
  component.authForm.setValue({ email: 'newuser@company.com', password: 'Strong#1234' });
    authServiceMock.signup.and.returnValue(
      throwError(() => ({
        status: 400,
        error: { errors: ['Duplicate entry for email'] }
      }))
    );

    component.onSubmit();

    expect(snackBarMock.open).toHaveBeenCalledWith('Email already exists', 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  });

  it('should detect not-authorized via regex text in login error payload', () => {
    const { component } = createComponent();
    component.isLoginMode = true;
    component.authForm.setValue({ email: 'user@test.com', password: 'secret' });
    authServiceMock.login.and.returnValue(
      throwError(() => ({
        status: 400,
        error: { errors: ['User not allowed to access this resource'] }
      }))
    );

    component.onSubmit();

    expect(snackBarMock.open).toHaveBeenCalledWith('You are not allowed to access', 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  });

  ignoreTest('should trigger mode toggle when toggle hyperlink is clicked (UI interaction)', () => {
    // Arrange
    const { fixture, component } = createComponent();
    spyOn(component, 'toggleMode').and.callThrough();
    const toggleAnchor = fixture.nativeElement.querySelector('.toggle-mode a') as HTMLAnchorElement;

    // Act
    toggleAnchor.click();
    fixture.detectChanges();

    // Assert
    expect(component.toggleMode).toHaveBeenCalled();
    expect(component.isLoginMode).toBeFalse();
  });
});
