import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../shared/services/auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
 
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  isLoginMode = true;
  hidePassword = true;
  hideConfirmPassword = true;
  loading = false;
  submitted = false;
  authForm: FormGroup;
 
  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {
    this.authForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]]
    });

    this.applyModeValidators();

    if (this.authService.isLoggedIn) {
      this.router.navigate(['/dashboard']);
    }
  }

  get emailControl(): AbstractControl {
    return this.authForm.get('email')!;
  }

  get passwordControl(): AbstractControl {
    return this.authForm.get('password')!;
  }
 
  toggleMode(): void {
    this.isLoginMode = !this.isLoginMode;
    this.hidePassword = true;
    this.hideConfirmPassword = true;
    this.loading = false;
    this.submitted = false;
    this.authForm.reset();
    this.applyModeValidators();
  }

  togglePasswordVisibility(): void {
    this.hidePassword = !this.hidePassword;
  }

  toggleConfirmPasswordVisibility(): void {
    this.hideConfirmPassword = !this.hideConfirmPassword;
  }

  onEmailInput(): void {
    if (!this.emailControl.hasError('emailTaken')) {
      return;
    }

    const currentErrors = { ...(this.emailControl.errors || {}) };
    delete currentErrors['emailTaken'];
    this.emailControl.setErrors(Object.keys(currentErrors).length ? currentErrors : null);
  }

  normalizeEmailOnBlur(): void {
    const normalized = String(this.emailControl.value || '').trim().toLowerCase();
    if (normalized !== this.emailControl.value) {
      this.emailControl.setValue(normalized);
    }
  }

  showEmailError(errorKey: string): boolean {
    return this.shouldShowControlErrors(this.emailControl) && this.emailControl.hasError(errorKey);
  }

  showPasswordError(errorKey: string): boolean {
    return this.shouldShowControlErrors(this.passwordControl) && this.passwordControl.hasError(errorKey);
  }

  hasPasswordStrengthError(key: string): boolean {
    const errors = this.passwordControl.errors?.['passwordStrength'];
    return !!errors?.[key] && this.shouldShowControlErrors(this.passwordControl);
  }

  get passwordChecks(): Array<{ label: string; met: boolean }> {
    const value = String(this.passwordControl.value || '');

    return [
      { label: '6-12 characters', met: value.length >= 6 && value.length <= 12 },
      { label: 'At least 1 uppercase letter', met: /[A-Z]/.test(value) },
      { label: 'At least 1 lowercase letter', met: /[a-z]/.test(value) },
      { label: 'At least 1 number', met: /\d/.test(value) },
      { label: 'At least 1 special character', met: /[^A-Za-z0-9]/.test(value) },
      { label: 'No spaces', met: value.length > 0 && !/\s/.test(value) }
    ];
  }
 
  onSubmit(): void {
    this.submitted = true;
    this.authForm.markAllAsTouched();

    if (this.authForm.invalid) {
      this.showInfoToast('Please correct the highlighted fields.');
      return;
    }

    const email = String(this.emailControl.value || '').trim().toLowerCase();
    const password = String(this.passwordControl.value || '');
 
    this.loading = true;
 
    if (this.isLoginMode) {
      this.authService.login({ email, password }).subscribe({
        next: () => {
          this.loading = false;
          this.showSuccessToast('Login successful');
          this.router.navigate(['/dashboard']);
        },
        error: (err: any) => {
          this.loading = false;
          this.showErrorToast(this.resolveAuthErrorMessage(err));
        }
      });
    } else {
      this.authService.signup({ email, password }).subscribe({
        next: () => {
          this.loading = false;
          this.showSuccessToast('User created successfully');
          this.authForm.reset();
          this.isLoginMode = true;
          this.submitted = false;
        },
        error: (err: any) => {
          this.loading = false;
          if (this.isEmailTakenError(err)) {
            const currentErrors = { ...(this.emailControl.errors || {}) };
            this.emailControl.setErrors({ ...currentErrors, emailTaken: true });
            this.emailControl.markAsTouched();
          }

          this.showErrorToast(this.resolveAuthErrorMessage(err));
        }
      });
    }
  }
   
  private isEmailTakenError(err: any): boolean {
    const status = err?.status;
    const serverMessage = String(err?.error?.message || err?.message || '').toLowerCase();
    const serverErrors = Array.isArray(err?.error?.errors)
      ? err.error.errors.join(' ').toLowerCase()
      : '';
    const merged = `${serverMessage} ${serverErrors}`;

    return status === 409 || /already exists|already registered|duplicate|email.*taken|email.*exists/.test(merged);
  }

  private shouldShowControlErrors(control: AbstractControl): boolean {
    return !!(control && (control.touched || this.submitted));
  }

  private applyModeValidators(): void {
    if (this.isLoginMode) {
      this.passwordControl.setValidators([Validators.required]);
    } else {
      this.passwordControl.setValidators([
        Validators.required,
        this.passwordStrengthValidator()
      ]);
    }

    this.passwordControl.updateValueAndValidity({ emitEvent: false });
  }

  private passwordStrengthValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = String(control.value || '');

      if (!value) {
        return null;
      }

      const errors: Record<string, boolean> = {};

  if (value.length < 6) errors['minLength'] = true;
  if (value.length > 12) errors['maxLength'] = true;
      if (!/[A-Z]/.test(value)) errors['uppercase'] = true;
      if (!/[a-z]/.test(value)) errors['lowercase'] = true;
      if (!/\d/.test(value)) errors['number'] = true;
      if (!/[^A-Za-z0-9]/.test(value)) errors['special'] = true;
      if (/\s/.test(value)) errors['whitespace'] = true;

      return Object.keys(errors).length ? { passwordStrength: errors } : null;
    };
  }

  private resolveAuthErrorMessage(err: any): string {
    const status = err?.status;

    if (status === 403 || this.isUserNotAllowedError(err)) {
      return 'You are not allowed to access';
    }

    if (status === 409 || this.isEmailTakenError(err)) {
      return 'Email already exists';
    }

    if (status === 401) {
      return 'Invalid credentials';
    }

    return 'Something went wrong';
  }

  private isUserNotAllowedError(err: any): boolean {
    const status = err?.status;
    const serverMessage = String(err?.error?.message || err?.message || '').toLowerCase();
    const serverErrors = Array.isArray(err?.error?.errors)
      ? err.error.errors.join(' ').toLowerCase()
      : '';
    const merged = `${serverMessage} ${serverErrors}`;

    return status === 403 || /user not allowed|not authorized|not authorised|unauthorized|unauthorised/.test(merged);
  }

  private showSuccessToast(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 2600,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-success']
    });
  }

  private showErrorToast(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  }

  private showInfoToast(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 2600,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast']
    });
  }
}