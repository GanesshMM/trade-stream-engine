import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FileService } from '../shared/services/file.service';
import { FileLoad } from '../shared/models/models';


@Component({
  selector: 'app-file-details',
  templateUrl: './file-details.component.html',
  styleUrls: ['./file-details.component.css']
})
export class FileDetailsComponent implements OnInit {
  loading = false;
  file: FileLoad | null = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private fileService: FileService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (!id || Number.isNaN(id)) {
      this.showInfoToast('Invalid file ID');
      this.goBack();
      return;
    }

    this.loading = true;
    this.fileService.searchFiles({ fileId: id }).subscribe({
      next: (res: any) => {
        const rows = Array.isArray(res?.data) ? res.data : [];
        this.file = rows.length ? rows[0] : null;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.showErrorToast('Failed to load file details');
      }
    });
  }

  goBack(): void {
    this.router.navigate(['/files']);
  }

  formatFileId(id: number): string {
    const year = new Date().getFullYear();
    return `FL-${year}-${String(id).padStart(5, '0')}`;
  }

  formatNumber(value: number): string {
    return Number(value || 0).toLocaleString('en-US');
  }

  formatDateTime(value: string): string {
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return value || '-';
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }

  formatStatusLabel(status: string): string {
    const normalized = (status || 'UNKNOWN').toUpperCase();
    return normalized === 'COMPLETED_WITH_ERROR' ? 'PARTIALLY_COMPLETED' : normalized;
  }

  private showInfoToast(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 2400,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast']
    });
  }

  private showErrorToast(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  }
}
