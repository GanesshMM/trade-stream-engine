import { Routes } from '@angular/router';

import { LoginComponent } from './auth/login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FileDetailsComponent } from './file-details/file-details.component';
import { FileManagementComponent } from './file-management/file-management.component';
import { ErrorManagementComponent } from './error-management/error-management.component';
import { AboutComponent } from './about/about.component';
import { AuthGuard } from './shared/guards/auth.guard';

export const AppRoutingModule: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard]
  },

  
  {
  path: 'upload',
  loadComponent: () =>
    import('./upload-file/upload-file.component')
      .then(m => m.UploadFileComponent),
  canActivate: [AuthGuard]
  },

  {
    path: 'files',
    component: FileManagementComponent,
    canActivate: [AuthGuard]
  },

  {
    path: 'files/:id',
    component: FileDetailsComponent,
    canActivate: [AuthGuard]
  },

  {
    path: 'errors',
    component: ErrorManagementComponent,
    canActivate: [AuthGuard]
  },

  {
    path: 'about',
    component: AboutComponent,
    canActivate: [AuthGuard]
  },

  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },

  {
    path: '**',
    redirectTo: 'dashboard'
  }
];