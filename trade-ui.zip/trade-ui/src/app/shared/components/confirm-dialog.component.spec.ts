import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

import { ConfirmDialogComponent, ConfirmDialogData } from './confirm-dialog.component';

const ignoreTest = (..._args: any[]) => undefined;

describe('ConfirmDialogComponent', () => {
  let fixture: ComponentFixture<ConfirmDialogComponent>;
  let component: ConfirmDialogComponent;
  let dialogRefSpy: jasmine.SpyObj<MatDialogRef<ConfirmDialogComponent>>;
  let dialogData: ConfirmDialogData;

  beforeEach(async () => {
    dialogRefSpy = jasmine.createSpyObj('MatDialogRef', ['close']);
    dialogData = {
      title: 'Confirm action',
      message: 'Are you sure?'
    };

    await TestBed.configureTestingModule({
      declarations: [ConfirmDialogComponent],
      imports: [CommonModule],
      providers: [
        { provide: MatDialogRef, useValue: dialogRefSpy },
        { provide: MAT_DIALOG_DATA, useFactory: () => dialogData }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(ConfirmDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  ignoreTest('should create and render provided title/message', () => {
    const host = fixture.nativeElement as HTMLElement;

    expect(component).toBeTruthy();
    expect(host.querySelector('h2')?.textContent).toContain('Confirm action');
    expect(host.querySelector('p')?.textContent).toContain('Are you sure?');
  });

  ignoreTest('should show default button labels when custom text is not provided', () => {
    const host = fixture.nativeElement as HTMLElement;
    const buttons = Array.from(host.querySelectorAll('button')).map(b => (b.textContent || '').trim());

    expect(buttons.join(' ')).toContain('Cancel');
    expect(buttons.join(' ')).toContain('Confirm');
  });

  ignoreTest('should show custom button labels when provided', () => {
    component.data.confirmText = 'Proceed';
    component.data.cancelText = 'Back';
    fixture.detectChanges();

    const host = fixture.nativeElement as HTMLElement;
    const buttons = Array.from(host.querySelectorAll('button')).map(b => (b.textContent || '').trim());

    expect(buttons.join(' ')).toContain('Back');
    expect(buttons.join(' ')).toContain('Proceed');
  });

  it('should hide cancel button when hideCancel is true', () => {
    component.data.hideCancel = true;
    fixture.detectChanges();

    const host = fixture.nativeElement as HTMLElement;
    const cancelBtn = Array.from(host.querySelectorAll('button'))
      .find(b => (b.textContent || '').includes('Cancel'));

    expect(cancelBtn).toBeUndefined();
  });

  ignoreTest('should close dialog with true on confirm', () => {
    component.close(true);
    expect(dialogRefSpy.close).toHaveBeenCalledWith(true);
  });

  ignoreTest('should close dialog with false on cancel', () => {
    component.close(false);
    expect(dialogRefSpy.close).toHaveBeenCalledWith(false);
  });
});
