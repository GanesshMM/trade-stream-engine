import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

export interface ConfirmDialogData {
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  hideCancel?: boolean;
}

@Component({
  selector: 'app-confirm-dialog',
  template: `
    <h2 mat-dialog-title>{{ data.title }}</h2>

    <mat-dialog-content>
      <p>{{ data.message }}</p>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button *ngIf="!data.hideCancel" mat-stroked-button class="cancel-btn" (click)="close(false)">
        {{ data.cancelText || 'Cancel' }}
      </button>
      <button mat-raised-button color="primary" class="confirm-btn" (click)="close(true)">
        {{ data.confirmText || 'Confirm' }}
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    :host {
      display: block;
      min-width: 340px;
    }

    h2[mat-dialog-title] {
      margin: 0;
      font-size: 1.08rem;
      font-weight: 700;
      color: #173252;
    }

    mat-dialog-content p {
      margin: 8px 0 0;
      color: #4f647d;
      font-size: 0.92rem;
      line-height: 1.45;
    }

    mat-dialog-actions {
      padding-top: 8px;
      gap: 8px;
    }

    .cancel-btn,
    .confirm-btn {
      min-width: 96px;
      height: 38px;
      border-radius: 9px !important;
      font-weight: 700;
    }
  `]
})
export class ConfirmDialogComponent {
  constructor(
    private dialogRef: MatDialogRef<ConfirmDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ConfirmDialogData
  ) {}

  close(confirmed: boolean): void {
    this.dialogRef.close(confirmed);
  }
}
