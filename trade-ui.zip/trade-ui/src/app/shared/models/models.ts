export interface ApiResponse<T> {
  timestamp: string;
  status: string;
  code: number;
  message: string;
  data: T;
  errors: string[];
}

export interface FileLoad {
  fileId: number;
  filename: string;
  uploadTime: string;
  totalRecords: number;
  successCount: number;
  errorCount: number;
  status: string;
}

export interface FileUploadResponse {
  fileId: number;
  fileName: string;
  status: string;
  message: string;
}

export interface TransactionError {
  errorId: number;
  fileId: number;
  transactionId: string;
  accountNumber: string;
  errorField: string;
  errorMessage: string;
  status: string;
  createdTime?: string;
}

export interface DashboardMetricsResponse {
  totalFiles: number;
  successRecords: number;
  errorRecords: number;
}

export interface DashboardStats {
  totalFilesProcessed: number;
  completedFiles: number;
  failedFiles: number;
  filesWithErrors: number;
  totalTransactions: number;
  totalErrors: number;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  tokenType: string;
  username: string;
  role: string;
  expiresIn: number;
}

export interface RegisterRequest {
  email: string;
  password: string;
}

export interface PageResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  size: number;
  number: number;
}
