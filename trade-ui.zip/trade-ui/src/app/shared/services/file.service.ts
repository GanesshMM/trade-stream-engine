import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '@env/environment';
import {
  ApiResponse,
  FileLoad,
  FileUploadResponse,
  DashboardMetricsResponse
} from '../models/models';

@Injectable({ providedIn: 'root' })
export class FileService {

  private apiUrl = `${environment.apiUrl}/file`;

  constructor(private http: HttpClient) {}

  getApiBaseUrl(): string {
    return this.apiUrl;
  }

  checkBackendConnection(): Observable<ApiResponse<FileLoad[]>> {
    return this.getAllFiles();
  }

  
  uploadFile(file: File): Observable<ApiResponse<FileUploadResponse>> {
    const formData = new FormData();
    formData.append('file', file);

    return this.http.post<ApiResponse<FileUploadResponse>>(
      `${this.apiUrl}/upload`,
      formData
    );
  }

  
  searchFiles(params: any): Observable<ApiResponse<FileLoad[]>> {
    return this.http.post<ApiResponse<FileLoad[]>>(
      `${this.apiUrl}/search`,
      params || {}
    ).pipe(map(res => this.normalizeFileListResponse(res)));
  }

  getMetrics(): Observable<ApiResponse<DashboardMetricsResponse>> {
    return this.http.get<ApiResponse<DashboardMetricsResponse>>(`${this.apiUrl}/metrics`);
  }

  getAllFiles(): Observable<ApiResponse<FileLoad[]>> {
    return this.http.get<ApiResponse<FileLoad[]>>(`${this.apiUrl}/getAll`)
      .pipe(map(res => this.normalizeFileListResponse(res)));
  }

  updateStatus(id: number, status: string): Observable<ApiResponse<FileLoad>> {
    return this.http.put<ApiResponse<FileLoad>>(
      `${this.apiUrl}/modify`,
      { fileId: id, status }
    );
  }

  deleteFile(id: number): Observable<ApiResponse<void>> {
    return this.http.delete<ApiResponse<void>>(`${this.apiUrl}/delete/${id}`);
  }

  archiveFile(id: number): Observable<ApiResponse<void>> {
    return this.http.post<ApiResponse<void>>(
      `${this.apiUrl}/archive/${id}`,
      {}
    );
  }

  private normalizeFileListResponse(response: ApiResponse<FileLoad[]>): ApiResponse<FileLoad[]> {
    const list = Array.isArray(response?.data) ? response.data : [];
    const normalized = list.map(item => this.normalizeFileLoad(item));
    return { ...response, data: normalized };
  }

  private normalizeFileLoad(item: FileLoad & { id?: number }): FileLoad {
    const fileId = item.fileId ?? item.id ?? 0;
    return { ...item, fileId } as FileLoad;
  }

  
}