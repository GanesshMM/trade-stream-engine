import { TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AuthService } from './auth.service';
import { ApiResponse, LoginResponse } from '../models/models';

const ignoreTest = (..._args: any[]) => undefined;

describe('AuthService', () => {
  let service: AuthService;
  let httpMock: HttpTestingController;

  const apiResponse = <T>(data: T): ApiResponse<T> => ({
    timestamp: new Date().toISOString(),
    status: 'OK',
    code: 200,
    message: 'success',
    data,
    errors: []
  });

  beforeEach(() => {
    localStorage.clear();

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });

    service = TestBed.inject(AuthService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
    localStorage.clear();
  });

  ignoreTest('should be created and logged out by default', () => {
    expect(service).toBeTruthy();
    expect(service.isLoggedIn).toBeFalse();
  });

  it('should normalize Bearer token from localStorage', () => {
    localStorage.setItem('token', 'Bearer abc123');
    expect(service.token).toBe('abc123');
  });

  it('should clear invalid token value from localStorage', () => {
    localStorage.setItem('token', '[object Object]');

    expect(service.token).toBeNull();
    expect(localStorage.getItem('token')).toBeNull();
  });

  it('should login with string token and mark as logged in', () => {
    service.login({ email: 'user@test.com', password: 'secret' }).subscribe();

    const req = httpMock.expectOne(request => request.url.endsWith('/auth/login'));
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ email: 'user@test.com', password: 'secret' });

    req.flush(apiResponse('Bearer jwt-001'));

    expect(localStorage.getItem('token')).toBe('jwt-001');
    expect(service.isLoggedIn).toBeTrue();
  });

  ignoreTest('should login with object token and store username/role', () => {
    const payload: LoginResponse = {
      token: 'Bearer jwt-obj',
      tokenType: 'Bearer',
      username: 'v.ramesh',
      role: 'ADMIN',
      expiresIn: 3600
    };

    service.login({ email: 'admin@test.com', password: 'secret' }).subscribe();

    const req = httpMock.expectOne(request => request.url.endsWith('/auth/login'));
    req.flush(apiResponse(payload));

    expect(localStorage.getItem('token')).toBe('jwt-obj');
    expect(localStorage.getItem('username')).toBe('v.ramesh');
    expect(localStorage.getItem('role')).toBe('ADMIN');
    expect(service.isLoggedIn).toBeTrue();
  });

  it('should logout when login response has no usable token', () => {
    localStorage.setItem('token', 'old-token');
    localStorage.setItem('username', 'user');
    localStorage.setItem('role', 'OPERATOR');

    service.login({ email: 'user@test.com', password: 'secret' }).subscribe();

    const req = httpMock.expectOne(request => request.url.endsWith('/auth/login'));
    req.flush(apiResponse({} as unknown as LoginResponse));

    expect(localStorage.getItem('token')).toBeNull();
    expect(localStorage.getItem('username')).toBeNull();
    expect(localStorage.getItem('role')).toBeNull();
    expect(service.isLoggedIn).toBeFalse();
  });

  ignoreTest('should call register endpoint with email/password payload', () => {
    service.register({ email: 'new@test.com', password: 'newpass' }).subscribe();

    const req = httpMock.expectOne(request => request.url.endsWith('/auth/signup'));
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ email: 'new@test.com', password: 'newpass' });

    req.flush(apiResponse('registered'));
  });

  ignoreTest('should clear storage and update login state on logout', () => {
    localStorage.setItem('token', 'abc');
    localStorage.setItem('username', 'demo');
    localStorage.setItem('role', 'ADMIN');

    service.logout();

    expect(localStorage.getItem('token')).toBeNull();
    expect(localStorage.getItem('username')).toBeNull();
    expect(localStorage.getItem('role')).toBeNull();
    expect(service.isLoggedIn).toBeFalse();
  });

  it('should evaluate role helper methods correctly', () => {
    localStorage.setItem('role', 'ADMIN');
    expect(service.hasRole('ADMIN')).toBeTrue();
    expect(service.isAdmin()).toBeTrue();
    expect(service.isOperator()).toBeFalse();

    localStorage.setItem('role', 'OPERATOR');
    expect(service.isAdmin()).toBeFalse();
    expect(service.isOperator()).toBeTrue();
  });

  ignoreTest('should initialize as logged in when valid token already exists', () => {
    localStorage.setItem('token', 'Bearer preloaded');
    const httpClient = TestBed.inject(HttpClient);

    const freshService = new AuthService(httpClient);

    expect(freshService.isLoggedIn).toBeTrue();
    expect(freshService.token).toBe('preloaded');
  });
});
