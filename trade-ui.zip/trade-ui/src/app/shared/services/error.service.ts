import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';
import { ApiResponse, TransactionError } from '../models/models';

@Injectable({ providedIn: 'root' })
export class ErrorService {
  private apiUrl = `${environment.apiUrl}/file`;

  constructor(private http: HttpClient) {}

  getAllErrors(): Observable<ApiResponse<TransactionError[]>> {
    return this.http.get<ApiResponse<TransactionError[]>>(`${this.apiUrl}/errors`);
  }

  searchErrors(params: any): Observable<ApiResponse<TransactionError[]>> {
    return this.http.post<ApiResponse<TransactionError[]>>(
      `${this.apiUrl}/search-errors`,
      params || {}
    );
  }
}
