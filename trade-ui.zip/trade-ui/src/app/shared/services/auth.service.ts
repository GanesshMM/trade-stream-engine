import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject, tap } from 'rxjs';
import { environment } from '@env/environment';
import { ApiResponse, LoginResponse } from '../models/models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private apiUrl = `${environment.apiUrl}/auth`;
  private loggedIn = new BehaviorSubject<boolean>(this.hasToken());

  constructor(private http: HttpClient) {}

  get isLoggedIn$(): Observable<boolean> {
    return this.loggedIn.asObservable();
  }

  get isLoggedIn(): boolean {
    return this.loggedIn.value;
  }

  get token(): string | null {
    const raw = localStorage.getItem('token');
    const normalized = this.normalizeToken(raw);

    if (!normalized && raw) {
      localStorage.removeItem('token');
    }

    return normalized;
  }

  get username(): string | null {
    return localStorage.getItem('username');
  }

  get role(): string | null {
    return localStorage.getItem('role');
  }

  login(request: { email: string; password: string }): Observable<ApiResponse<string | LoginResponse>> {
    const payload: { email: string; password: string } = {
      email: request.email,
      password: request.password
    };

    return this.http.post<ApiResponse<string | LoginResponse>>(`${this.apiUrl}/login`, payload)
      .pipe(tap(response => {
        const data = response?.data;
        const token = this.extractToken(data);

        if (token) {
          localStorage.setItem('token', token);

          if (typeof data !== 'string') {
            if (data.username) {
              localStorage.setItem('username', data.username);
            }
            if (data.role) {
              localStorage.setItem('role', data.role);
            }
          }

          this.loggedIn.next(true);
        } else {
          this.logout();
        }
      }));
  }

  signup(request: { email: string; password: string }): Observable<ApiResponse<string>> {
    const payload: { email: string; password: string } = {
      email: request.email,
      password: request.password
    };

    return this.http.post<ApiResponse<string>>(`${this.apiUrl}/signup`, payload);
  }

  register(request: { email: string; password: string }): Observable<ApiResponse<string>> {
    return this.signup(request);
  }

  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    localStorage.removeItem('role');
    this.loggedIn.next(false);
  }

  private hasToken(): boolean {
    return !!this.token;
  }

  private extractToken(data: string | LoginResponse | null | undefined): string | null {
    if (!data) return null;

    if (typeof data === 'string') {
      return this.normalizeToken(data);
    }

    return this.normalizeToken(
      data.token || (data as any).accessToken || (data as any).jwt || null
    );
  }

  private normalizeToken(value: string | null | undefined): string | null {
    if (!value) return null;

    let token = value.trim();
    if (!token) return null;

    token = token.replace(/^Bearer\s+/i, '').trim();

    const invalidValues = new Set(['undefined', 'null', '[object Object]']);
    if (!token || invalidValues.has(token)) {
      return null;
    }

    return token;
  }

  hasRole(role: string): boolean {
    return this.role === role;
  }

  isAdmin(): boolean {
    return this.role === 'ADMIN';
  }

  isOperator(): boolean {
    return this.role === 'OPERATOR';
  }
}
