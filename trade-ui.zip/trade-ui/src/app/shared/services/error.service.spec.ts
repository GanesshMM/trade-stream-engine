import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { ErrorService } from './error.service';
import { ApiResponse, TransactionError } from '../models/models';

const ignoreTest = (..._args: any[]) => undefined;

describe('ErrorService', () => {
  let service: ErrorService;
  let httpMock: HttpTestingController;

  const apiResponse = <T>(data: T): ApiResponse<T> => ({
    timestamp: new Date().toISOString(),
    status: 'OK',
    code: 200,
    message: 'success',
    data,
    errors: []
  });

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });

    service = TestBed.inject(ErrorService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  ignoreTest('should fetch all errors from /errors endpoint', () => {
    service.getAllErrors().subscribe((res) => {
      expect(res.data.length).toBe(1);
      expect(res.data[0].errorId).toBe(1);
    });

    const req = httpMock.expectOne(r => r.url.endsWith('/file/errors'));
    expect(req.request.method).toBe('GET');

    req.flush(apiResponse([
      {
        errorId: 1,
        fileId: 100,
        transactionId: 'TX-1',
        accountNumber: 'ACC-1',
        errorField: 'status',
        errorMessage: 'Invalid',
        status: 'FAILED'
      }
    ] as TransactionError[]));
  });

  it('should post search params to /search-errors endpoint', () => {
    const params = { fileId: 99, status: 'FAILED' };

    service.searchErrors(params).subscribe();

    const req = httpMock.expectOne(r => r.url.endsWith('/file/search-errors'));
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual(params);

    req.flush(apiResponse([] as TransactionError[]));
  });

  ignoreTest('should send empty object when search params are null', () => {
    service.searchErrors(null).subscribe();

    const req = httpMock.expectOne(r => r.url.endsWith('/file/search-errors'));
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({});

    req.flush(apiResponse([] as TransactionError[]));
  });
});
