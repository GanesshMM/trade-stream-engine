import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { FileService } from './file.service';
import { ApiResponse, FileLoad, DashboardMetricsResponse, FileUploadResponse } from '../models/models';

const ignoreTest = (..._args: any[]) => undefined;

describe('FileService', () => {
  let service: FileService;
  let httpMock: HttpTestingController;

  const apiResponse = <T>(data: T): ApiResponse<T> => ({
    timestamp: new Date().toISOString(),
    status: 'OK',
    code: 200,
    message: 'success',
    data,
    errors: []
  });

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });

    service = TestBed.inject(FileService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  ignoreTest('should expose API base url ending with /file', () => {
    expect(service.getApiBaseUrl().endsWith('/file')).toBeTrue();
  });

  ignoreTest('should call getAll through checkBackendConnection', () => {
    service.checkBackendConnection().subscribe();

    const req = httpMock.expectOne(r => r.url.endsWith('/file/getAll'));
    expect(req.request.method).toBe('GET');
    req.flush(apiResponse([] as FileLoad[]));
  });

  it('should upload file as multipart form data', () => {
    const file = new File(['a,b'], 'sample.csv', { type: 'text/csv' });

    service.uploadFile(file).subscribe((res) => {
      expect(res.data.fileId).toBe(1);
    });

    const req = httpMock.expectOne(r => r.url.endsWith('/file/upload'));
    expect(req.request.method).toBe('POST');
    expect(req.request.body instanceof FormData).toBeTrue();

    req.flush(apiResponse({
      fileId: 1,
      fileName: 'sample.csv',
      status: 'PROCESSING',
      message: 'Uploaded'
    } as FileUploadResponse));
  });

  it('should post search params and normalize fileId from id fallback', () => {
    const request = { status: 'COMPLETED' };

    service.searchFiles(request).subscribe((res) => {
      expect(res.data.length).toBe(1);
      expect(res.data[0].fileId).toBe(77);
    });

    const req = httpMock.expectOne(r => r.url.endsWith('/file/search'));
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual(request);

    req.flush(apiResponse([
      {
        id: 77,
        filename: 'records.csv',
        uploadTime: new Date().toISOString(),
        totalRecords: 10,
        successCount: 9,
        errorCount: 1,
        status: 'COMPLETED'
      } as any
    ]));
  });

  it('should send empty object when search params are null', () => {
    service.searchFiles(null).subscribe();

    const req = httpMock.expectOne(r => r.url.endsWith('/file/search'));
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({});

    req.flush(apiResponse([] as FileLoad[]));
  });

  ignoreTest('should return empty data when getAll receives non-array payload', () => {
    service.getAllFiles().subscribe((res) => {
      expect(res.data).toEqual([]);
    });

    const req = httpMock.expectOne(r => r.url.endsWith('/file/getAll'));
    expect(req.request.method).toBe('GET');
    req.flush(apiResponse({} as any));
  });

  ignoreTest('should call metrics endpoint', () => {
    service.getMetrics().subscribe((res) => {
      expect(res.data.totalFiles).toBe(5);
    });

    const req = httpMock.expectOne(r => r.url.endsWith('/file/metrics'));
    expect(req.request.method).toBe('GET');
    req.flush(apiResponse({
      totalFiles: 5,
      successRecords: 100,
      errorRecords: 3
    } as DashboardMetricsResponse));
  });

  it('should update status via PUT /modify', () => {
    service.updateStatus(11, 'ARCHIVED').subscribe();

    const req = httpMock.expectOne(r => r.url.endsWith('/file/modify'));
    expect(req.request.method).toBe('PUT');
    expect(req.request.body).toEqual({ fileId: 11, status: 'ARCHIVED' });

    req.flush(apiResponse({
      fileId: 11,
      filename: 'x.csv',
      uploadTime: new Date().toISOString(),
      totalRecords: 1,
      successCount: 1,
      errorCount: 0,
      status: 'ARCHIVED'
    } as FileLoad));
  });

  ignoreTest('should delete file by id', () => {
    service.deleteFile(5).subscribe();

    const req = httpMock.expectOne(r => r.url.endsWith('/file/delete/5'));
    expect(req.request.method).toBe('DELETE');
    req.flush(apiResponse(undefined));
  });

  it('should archive file by id', () => {
    service.archiveFile(9).subscribe();

    const req = httpMock.expectOne(r => r.url.endsWith('/file/archive/9'));
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({});

    req.flush(apiResponse(undefined));
  });
});
