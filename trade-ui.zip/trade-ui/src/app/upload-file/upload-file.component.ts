import { CommonModule } from '@angular/common';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { HttpErrorResponse } from '@angular/common/http';
import { FileService } from '../shared/services/file.service';
import { ConfirmDialogComponent } from '../shared/components/confirm-dialog.component';

@Component({
  selector: 'app-upload-file',
  standalone: true, 
  imports: [CommonModule, MatButtonModule, MatIconModule, MatSnackBarModule],
  templateUrl: './upload-file.component.html',
  styleUrls: ['./upload-file.component.css']
})
export class UploadFileComponent { 

  @ViewChild('fileInput') fileInputRef!: ElementRef<HTMLInputElement>;

  uploading = false;
  isDragOver = false;
  selectedFile: File | null = null;

  constructor(
    private fileService: FileService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog
  ) {}

  triggerFilePicker(): void {
    this.fileInputRef.nativeElement.value = '';
    this.fileInputRef.nativeElement.click();
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (file) {
      if(file.name.toLowerCase().endsWith('.csv')) {
        this.selectedFile = file;
      } else {
        this.showInfoToast('Please select a CSV file.');
        input.value = '';
      }
    }
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragOver = true;
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragOver = false;
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragOver = false;
    
    if (event.dataTransfer?.files.length) {
      const file = event.dataTransfer.files[0];
      if (file.name.toLowerCase().endsWith('.csv')) {
        this.selectedFile = file;
        this.fileInputRef.nativeElement.files = event.dataTransfer.files;
      } else {
        this.showInfoToast('Please drop a CSV file.');
      }
    }
  }

  uploadSelectedFile(event: Event): void {
    event.stopPropagation(); // prevent clicking the background area
    if (!this.selectedFile) return;

    this.uploading = true;

    this.fileService.uploadFile(this.selectedFile).subscribe({
      next: (res) => {
        this.uploading = false;
        this.selectedFile = null;
        this.showUploadSuccessPopup('The file was uploaded successfully.');
        this.fileInputRef.nativeElement.value = '';
      },
      error: (err: HttpErrorResponse) => {
        this.uploading = false;
        const msg = err.error?.message || err.message || 'Upload failed';
        this.showErrorToast(`Upload failed: ${msg}`);
      }
    });
  }

  private showUploadSuccessPopup(message: string): void {
    this.dialog.open(ConfirmDialogComponent, {
      width: '420px',
      disableClose: true,
      data: {
        title: 'Upload successful',
        message,
        confirmText: 'OK',
        hideCancel: true
      }
    });
  }

  private showErrorToast(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  }

  private showInfoToast(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 2600,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast']
    });
  }
}

export {};