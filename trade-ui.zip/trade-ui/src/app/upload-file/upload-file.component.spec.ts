import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ElementRef, NO_ERRORS_SCHEMA } from '@angular/core';
import { of, throwError } from 'rxjs';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { UploadFileComponent } from './upload-file.component';
import { FileService } from '../shared/services/file.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';

const ignoreTest = (..._args: any[]) => undefined;

describe('UploadFileComponent', () => {
  let fixture: ComponentFixture<UploadFileComponent>;
  let component: UploadFileComponent;

  let fileServiceMock: { uploadFile: jasmine.Spy };
  let snackBarOpenSpy: jasmine.Spy;
  let dialogOpenSpy: jasmine.Spy;

  const csvFile = new File(['id,name'], 'trades.csv', { type: 'text/csv' });
  const txtFile = new File(['bad'], 'bad.txt', { type: 'text/plain' });

  beforeEach(async () => {
    fileServiceMock = {
      uploadFile: jasmine.createSpy('uploadFile').and.returnValue(of({ data: { fileId: 1 } }))
    };

    await TestBed.configureTestingModule({
      imports: [UploadFileComponent, NoopAnimationsModule],
      providers: [
        { provide: FileService, useValue: fileServiceMock }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(UploadFileComponent);
    component = fixture.componentInstance;
    snackBarOpenSpy = spyOn((component as any).snackBar, 'open');
    dialogOpenSpy = spyOn((component as any).dialog, 'open');

    fixture.detectChanges();

    component.fileInputRef = new ElementRef({
      value: '',
      click: jasmine.createSpy('click'),
      files: null
    } as any);
  });

  ignoreTest('should create and render upload title', () => {
    // Arrange / Act
    const title = fixture.nativeElement.querySelector('.card-head h1')?.textContent?.trim();

    // Assert
    expect(component).toBeTruthy();
    expect(title).toBe('Upload File');
  });

  it('should reset file input and trigger picker on triggerFilePicker', () => {
    // Arrange
    const native = component.fileInputRef.nativeElement as any;

    // Act
    component.triggerFilePicker();

    // Assert
    expect(native.value).toBe('');
    expect(native.click).toHaveBeenCalled();
  });

  it('should accept CSV file selection', () => {
    // Arrange
    const input = { files: [csvFile], value: 'trades.csv' } as any;
    const event = { target: input } as unknown as Event;

    // Act
    component.onFileSelected(event);

    // Assert
    expect(component.selectedFile?.name).toBe('trades.csv');
  expect(snackBarOpenSpy).not.toHaveBeenCalled();
  });

  ignoreTest('should do nothing when no file is selected from picker', () => {
    const input = { files: [], value: '' } as any;
    const event = { target: input } as unknown as Event;

    component.onFileSelected(event);

    expect(component.selectedFile).toBeNull();
    expect(snackBarOpenSpy).not.toHaveBeenCalled();
  });

  it('should reject non-CSV file selection and show snackbar', () => {
    // Arrange
    const input = { files: [txtFile], value: 'bad.txt' } as any;
    const event = { target: input } as unknown as Event;

    // Act
    component.onFileSelected(event);

    // Assert
    expect(component.selectedFile).toBeNull();
    expect(input.value).toBe('');
    expect(snackBarOpenSpy).toHaveBeenCalledWith('Please select a CSV file.', 'Close', {
      duration: 2600,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast']
    });
  });

  ignoreTest('should manage drag state on drag over/leave', () => {
    // Arrange
    const dragEvent = {
      preventDefault: jasmine.createSpy('preventDefault'),
      stopPropagation: jasmine.createSpy('stopPropagation')
    } as any as DragEvent;

    // Act
    component.onDragOver(dragEvent);

    // Assert
    expect(component.isDragOver).toBeTrue();

    // Act
    component.onDragLeave(dragEvent);

    // Assert
    expect(component.isDragOver).toBeFalse();
  });

  it('should accept CSV file on drop', () => {
    // Arrange
    const dataTransfer = { files: [csvFile] } as any;
    const dropEvent = {
      preventDefault: jasmine.createSpy('preventDefault'),
      stopPropagation: jasmine.createSpy('stopPropagation'),
      dataTransfer
    } as any as DragEvent;

    // Act
    component.onDrop(dropEvent);

    // Assert
    expect(component.isDragOver).toBeFalse();
    expect(component.selectedFile?.name).toBe('trades.csv');
  });

  it('should reject non-CSV file on drop and show snackbar', () => {
    // Arrange
    const dataTransfer = { files: [txtFile] } as any;
    const dropEvent = {
      preventDefault: jasmine.createSpy('preventDefault'),
      stopPropagation: jasmine.createSpy('stopPropagation'),
      dataTransfer
    } as any as DragEvent;

    // Act
    component.onDrop(dropEvent);

    // Assert
    expect(component.selectedFile).toBeNull();
    expect(snackBarOpenSpy).toHaveBeenCalledWith('Please drop a CSV file.', 'Close', {
      duration: 2600,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast']
    });
  });

  ignoreTest('should do nothing on drop when no files are provided', () => {
    const dropEvent = {
      preventDefault: jasmine.createSpy('preventDefault'),
      stopPropagation: jasmine.createSpy('stopPropagation'),
      dataTransfer: { files: [] }
    } as any as DragEvent;

    component.onDrop(dropEvent);

    expect(component.selectedFile).toBeNull();
    expect(snackBarOpenSpy).not.toHaveBeenCalled();
  });

  it('should not call upload API when selectedFile is null', () => {
    // Arrange
    component.selectedFile = null;
    const clickEvent = { stopPropagation: jasmine.createSpy('stopPropagation') } as any as Event;

    // Act
    component.uploadSelectedFile(clickEvent);

    // Assert
    expect(fileServiceMock.uploadFile).not.toHaveBeenCalled();
  });

  it('should upload selected file successfully and reset state', () => {
    // Arrange
    component.selectedFile = csvFile;
    const clickEvent = { stopPropagation: jasmine.createSpy('stopPropagation') } as any as Event;

    // Act
    component.uploadSelectedFile(clickEvent);

    // Assert
    expect(fileServiceMock.uploadFile).toHaveBeenCalledWith(csvFile);
    expect(component.uploading).toBeFalse();
    expect(component.selectedFile).toBeNull();
    expect((component.fileInputRef.nativeElement as any).value).toBe('');
    expect(dialogOpenSpy).toHaveBeenCalled();
  });

  ignoreTest('should show upload error message on API failure', () => {
    // Arrange
    component.selectedFile = csvFile;
    fileServiceMock.uploadFile.and.returnValue(throwError(() => ({ error: { message: 'Backend failed' }, message: 'X' })));
    const clickEvent = { stopPropagation: jasmine.createSpy('stopPropagation') } as any as Event;

    // Act
    component.uploadSelectedFile(clickEvent);

    // Assert
    expect(component.uploading).toBeFalse();
    expect(snackBarOpenSpy).toHaveBeenCalledWith('Upload failed: Backend failed', 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  });

  ignoreTest('should use top-level error message fallback when nested message is missing', () => {
    component.selectedFile = csvFile;
    fileServiceMock.uploadFile.and.returnValue(throwError(() => ({ message: 'X-level fail' })));
    const clickEvent = { stopPropagation: jasmine.createSpy('stopPropagation') } as any as Event;

    component.uploadSelectedFile(clickEvent);

    expect(snackBarOpenSpy).toHaveBeenCalledWith('Upload failed: X-level fail', 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  });

  it('should fallback to generic upload failed when no error message exists', () => {
    component.selectedFile = csvFile;
    fileServiceMock.uploadFile.and.returnValue(throwError(() => ({ message: '' })));
    const clickEvent = { stopPropagation: jasmine.createSpy('stopPropagation') } as any as Event;

    component.uploadSelectedFile(clickEvent);

    expect(snackBarOpenSpy).toHaveBeenCalledWith('Upload failed: Upload failed', 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  });
});
