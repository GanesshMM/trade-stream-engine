import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';

import { HeaderComponent } from './header.component';
import { AuthService } from '../../shared/services/auth.service';

const ignoreTest = (..._args: any[]) => undefined;

describe('HeaderComponent (layout)', () => {
  let fixture: ComponentFixture<HeaderComponent>;
  let component: HeaderComponent;

  let authServiceMock: { isLoggedIn: boolean; logout: jasmine.Spy };
  let routerMock: { navigate: jasmine.Spy };

  beforeEach(async () => {
    authServiceMock = {
      isLoggedIn: false,
      logout: jasmine.createSpy('logout')
    };

    routerMock = {
      navigate: jasmine.createSpy('navigate')
    };

    await TestBed.configureTestingModule({
      declarations: [HeaderComponent],
      providers: [
        { provide: AuthService, useValue: authServiceMock },
        { provide: Router, useValue: routerMock }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  ignoreTest('should always render brand/title elements', () => {
    const logo = fixture.nativeElement.querySelector('.company-logo');
    const title = fixture.nativeElement.querySelector('.brand-title')?.textContent?.trim();

    expect(component).toBeTruthy();
    expect(logo).toBeTruthy();
    expect(title).toBe('Trade Stream Engine');
  });

  it('should hide nav links and logout when not authenticated', () => {
    authServiceMock.isLoggedIn = false;
    fixture.detectChanges();

    expect(fixture.nativeElement.querySelector('button[aria-label="Logout"]')).toBeNull();
  });

  ignoreTest('should show logout when authenticated', () => {
    authServiceMock.isLoggedIn = true;
    fixture.detectChanges();

    expect(fixture.nativeElement.querySelector('button[aria-label="Logout"]')).toBeTruthy();
  });

  it('should call logout and navigate to /login on logout()', () => {
    component.logout();

    expect(authServiceMock.logout).toHaveBeenCalled();
    expect(routerMock.navigate).toHaveBeenCalledWith(['/login']);
  });
});
