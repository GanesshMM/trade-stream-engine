import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';

import { SidebarComponent } from './sidebar.component';

const ignoreTest = (..._args: any[]) => undefined;

describe('SidebarComponent (layout)', () => {
  let fixture: ComponentFixture<SidebarComponent>;
  let component: SidebarComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SidebarComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(SidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  ignoreTest('should render expanded menu labels when isOpen=true', () => {
    component.isOpen = true;
    fixture.detectChanges();

    expect(fixture.nativeElement.querySelector('.nav-section-label')?.textContent?.trim()).toBe('MENU');
    expect(fixture.nativeElement.textContent).toContain('Upload File');
    expect(fixture.nativeElement.textContent).toContain('File Load Records');
    expect(fixture.nativeElement.textContent).toContain('Error Logs');
  });

  it('should collapse sidebar class and hide labels when isOpen=false', () => {
    component.isOpen = false;
    fixture.detectChanges();

    const nav = fixture.nativeElement.querySelector('nav.sidebar');
    expect(nav.classList).toContain('sidebar-collapsed');
    expect(fixture.nativeElement.querySelector('.nav-section-label')).toBeNull();
  });

  it('should emit toggleMenu when collapse button is clicked', () => {
    spyOn(component.toggleMenu, 'emit');

    const button = fixture.nativeElement.querySelector('button.collapse-toggle') as HTMLButtonElement;
    button.click();

    expect(component.toggleMenu.emit).toHaveBeenCalled();
  });

  ignoreTest('should switch chevron icon based on isOpen state', () => {
    component.isOpen = true;
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.collapse-toggle mat-icon')?.textContent?.trim()).toBe('chevron_left');

    component.isOpen = false;
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.collapse-toggle mat-icon')?.textContent?.trim()).toBe('chevron_right');
  });
});
