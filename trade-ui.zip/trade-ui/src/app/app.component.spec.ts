import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';

import { AppComponent } from './app.component';
import { AuthService } from './shared/services/auth.service';

describe('AppComponent (layout)', () => {
  let fixture: ComponentFixture<AppComponent>;
  let component: AppComponent;

  let authState$: BehaviorSubject<boolean>;

  const authServiceMock: any = {};
  const routerMock: any = {};

  beforeEach(async () => {
    authState$ = new BehaviorSubject<boolean>(false);

    authServiceMock.isLoggedIn$ = authState$.asObservable();
    routerMock.navigate = jasmine.createSpy('navigate');

    await TestBed.configureTestingModule({
      declarations: [AppComponent],
      providers: [
        { provide: AuthService, useValue: authServiceMock },
        { provide: Router, useValue: routerMock }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should render login layout (router-outlet only) when user is not logged in', () => {
    authState$.next(false);
    fixture.detectChanges();

    const header = fixture.nativeElement.querySelector('app-header');
    const sidebar = fixture.nativeElement.querySelector('app-sidebar');
    const footer = fixture.nativeElement.querySelector('app-footer');

    expect(header).toBeNull();
    expect(sidebar).toBeNull();
    expect(footer).toBeNull();
    expect(fixture.nativeElement.querySelectorAll('router-outlet').length).toBe(1);
  });

  it('should render app shell when user is logged in', () => {
    authState$.next(true);
    fixture.detectChanges();

    const header = fixture.nativeElement.querySelector('app-header');
    const footer = fixture.nativeElement.querySelector('app-footer');

    expect(header).toBeTruthy();
    expect(footer).toBeTruthy();
    expect(fixture.nativeElement.querySelector('.main-layout')).toBeTruthy();
    expect(fixture.nativeElement.querySelector('app-sidebar')).toBeTruthy();
  });

  it('should keep sidebar rendered for logged-in users', () => {
    authState$.next(true);
    component.sidebarOpen = true;
    fixture.detectChanges();

    expect(fixture.nativeElement.querySelector('app-sidebar')).toBeTruthy();
  });

  it('should toggle sidebar state via toggleSidebar()', () => {
    component.sidebarOpen = true;

    component.toggleSidebar();
    expect(component.sidebarOpen).toBeFalse();

    component.toggleSidebar();
    expect(component.sidebarOpen).toBeTrue();
  });
});
