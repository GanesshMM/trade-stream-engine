import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FileService } from '../shared/services/file.service';
import { FileLoad, ApiResponse } from '../shared/models/models';
import { ConfirmDialogComponent } from '../shared/components/confirm-dialog.component';

@Component({
  selector: 'app-file-management',
  templateUrl: './file-management.component.html',
  styleUrls: ['./file-management.component.css']
})
export class FileManagementComponent implements OnInit {

  readonly fileStatusOptions = Array.from(new Set([
    'STARTED',
    'PROCESSING',
    'COMPLETED',
    'COMPLETED_WITH_ERROR',
    'FAILED',
    'ARCHIVED',
    'DELETED'
  ]));
  readonly today = new Date();

  allFiles: FileLoad[] = [];
  files: FileLoad[] = [];
  loading = false;

  searchCriteria = {
    fileId: null as number | null,
    filename: '',
    status: '',
    startDate: null as Date | null,
    endDate: null as Date | null
  };

  displayedColumns = [
    'fileId', 'filename', 'status', 'uploadTime',
    'totalRecords', 'successCount', 'errorCount', 'actions'
  ];

  totalElements = 0;
  pageSize = 10;
  currentPage = 0;

  get isEndDateRequired(): boolean {
    return !!this.searchCriteria.startDate && !this.searchCriteria.endDate;
  }

  constructor(
    private fileService: FileService,
    private snackBar: MatSnackBar,
    private router: Router,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.searchFiles();
  }

  searchFiles(): void {
    this.loading = true;
    this.currentPage = 0;

    const request: any = {};
    if (this.searchCriteria.fileId !== null && this.searchCriteria.fileId !== undefined) {
      request.fileId = this.searchCriteria.fileId;
    }
    if (this.searchCriteria.filename.trim()) {
      request.filename = this.searchCriteria.filename.trim();
    }
    if (this.searchCriteria.status) {
      request.status = this.searchCriteria.status;
    }

    const hasStart = !!this.searchCriteria.startDate;
    const hasEnd = !!this.searchCriteria.endDate;
    if (hasStart !== hasEnd) {
      this.loading = false;
      this.showInfoToast('Please provide both start and end date.');
      return;
    }
    if (hasStart && hasEnd) {
      const startDate = this.searchCriteria.startDate as Date;
      const endDate = this.searchCriteria.endDate as Date;

      if (startDate.getTime() > endDate.getTime()) {
        this.loading = false;
        this.showInfoToast('End date must be on or after start date.');
        return;
      }

      request.startDate = this.toStartOfDayIso(this.searchCriteria.startDate as Date);
      request.endDate = this.toEndOfDayIso(this.searchCriteria.endDate as Date);
    }

    this.fileService.searchFiles(request).subscribe({
      next: (res: ApiResponse<FileLoad[]>) => {
        const data = Array.isArray(res.data) ? res.data : [];
        this.allFiles = data.sort((a, b) =>
          new Date(b.uploadTime || 0).getTime() - new Date(a.uploadTime || 0).getTime()
        );
        this.totalElements = this.allFiles.length;
        this.applyPagination();
        this.loading = false;
      },
      error: () => {
        this.allFiles = [];
        this.files = [];
        this.totalElements = 0;
        this.loading = false;
        this.showErrorToast('Failed to load files');
      }
    });
  }

  applySearch(): void {
    this.searchFiles();
  }

  clearSearch(): void {
    this.searchCriteria = {
      fileId: null,
      filename: '',
      status: '',
      startDate: null,
      endDate: null
    };
    this.searchFiles();
  }

  onPageChange(event: PageEvent): void {
    this.currentPage = event.pageIndex;
    this.pageSize = event.pageSize;
    this.applyPagination();
  }

  updateStatus(fileId: number, status: string): void {
    this.fileService.updateStatus(fileId, status).subscribe({
      next: () => {
        this.showSuccessToast('Status updated');
        this.searchFiles();
      },
      error: () => this.showErrorToast('Failed to update status')
    });
  }

  archiveFile(fileId: number): void {
    this.confirmAction('Archive File', 'Are you sure you want to archive this file?', 'Archive')
      .subscribe(confirmed => {
        if (!confirmed) return;

        this.fileService.archiveFile(fileId).subscribe({
          next: () => {
            this.showSuccessToast('File archived');
            this.searchFiles();
          },
          error: () => this.showErrorToast('Failed to archive file')
        });
      });
  }

  deleteFile(fileId: number): void {
    this.confirmAction('Delete File', 'Are you sure you want to delete this file?', 'Delete')
      .subscribe(confirmed => {
        if (!confirmed) return;

        this.fileService.deleteFile(fileId).subscribe({
          next: () => {
            this.showSuccessToast('File deleted');
            this.searchFiles();
          },
          error: () => this.showErrorToast('Failed to delete file')
        });
      });
  }

  private confirmAction(title: string, message: string, confirmText: string) {
    return this.dialog.open(ConfirmDialogComponent, {
      width: '420px',
      disableClose: true,
      data: {
        title,
        message,
        confirmText,
        cancelText: 'Cancel'
      }
    }).afterClosed();
  }

  viewFile(file: FileLoad): void {
    this.router.navigate(['/files', file.fileId]);
  }

  getDisplayFileId(rowIndex: number): number {
    return (this.currentPage * this.pageSize) + rowIndex + 1;
  }

  formatFileId(id: number): string {
    const year = new Date().getFullYear();
    return `FL-${year}-${String(id).padStart(5, '0')}`;
  }

  getStatusClass(status: string): string {
    const s = (status || '').toUpperCase();
    if (s === 'COMPLETED') return 'status-completed';
    if (s === 'STARTED' || s === 'PROCESSING') return 'status-processing';
    if (s === 'FAILED' || s === 'COMPLETED_WITH_ERROR') return 'status-failed';
    if (s === 'ARCHIVED' || s === 'DELETED') return 'status-archived';
    return 'status-processing';
  }

  getStatusLabel(status: string): string {
    const s = (status || '').toUpperCase();
    return s === 'COMPLETED_WITH_ERROR' ? 'PARTIALLY_COMPLETED' : s;
  }

  private toStartOfDayIso(date: Date): string {
    const d = new Date(date);
    d.setHours(0, 0, 0, 0);
    return this.toLocalDateTimeString(d);
  }

  private toEndOfDayIso(date: Date): string {
    const d = new Date(date);
    d.setHours(23, 59, 59, 999);
    return this.toLocalDateTimeString(d);
  }

  private toLocalDateTimeString(date: Date): string {
    const pad = (n: number) => String(n).padStart(2, '0');
    const year = date.getFullYear();
    const month = pad(date.getMonth() + 1);
    const day = pad(date.getDate());
    const hours = pad(date.getHours());
    const minutes = pad(date.getMinutes());
    const seconds = pad(date.getSeconds());

    return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
  }

  private applyPagination(): void {
    const start = this.currentPage * this.pageSize;
    const end = start + this.pageSize;
    this.files = this.allFiles.slice(start, end);
  }

  private showSuccessToast(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 2600,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-success']
    });
  }

  private showErrorToast(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  }

  private showInfoToast(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 2600,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast']
    });
  }
}