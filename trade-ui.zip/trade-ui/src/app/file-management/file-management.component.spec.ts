import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { of, throwError } from 'rxjs';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';

import { FileManagementComponent } from './file-management.component';
import { FileService } from '../shared/services/file.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';

import { FileLoad } from '../shared/models/models';

const ignoreTest = (..._args: any[]) => undefined;

describe('FileManagementComponent', () => {
  let fixture: ComponentFixture<FileManagementComponent>;
  let component: FileManagementComponent;

  let fileServiceMock: {
    searchFiles: jasmine.Spy;
    updateStatus: jasmine.Spy;
    archiveFile: jasmine.Spy;
    deleteFile: jasmine.Spy;
  };
  let snackBarMock: { open: jasmine.Spy };
  let routerMock: { navigate: jasmine.Spy };
  let dialogMock: { open: jasmine.Spy };

  const makeFiles = (count: number): FileLoad[] =>
    Array.from({ length: count }, (_, idx) => ({
      fileId: idx + 1,
      filename: `file-${idx + 1}.csv`,
      uploadTime: new Date(2026, 0, idx + 1).toISOString(),
      totalRecords: 100 + idx,
      successCount: 90 + idx,
      errorCount: 10,
      status: idx % 2 === 0 ? 'COMPLETED' : 'FAILED'
    }));

  beforeEach(async () => {
    fileServiceMock = {
      searchFiles: jasmine.createSpy('searchFiles').and.returnValue(of({ data: makeFiles(12) })),
      updateStatus: jasmine.createSpy('updateStatus').and.returnValue(of({ data: {} })),
      archiveFile: jasmine.createSpy('archiveFile').and.returnValue(of({ data: {} })),
      deleteFile: jasmine.createSpy('deleteFile').and.returnValue(of({ data: {} }))
    };

    snackBarMock = { open: jasmine.createSpy('open') };
    routerMock = { navigate: jasmine.createSpy('navigate') };
    dialogMock = {
      open: jasmine.createSpy('open').and.returnValue({
        afterClosed: () => of(true)
      })
    };

    await TestBed.configureTestingModule({
      declarations: [FileManagementComponent],
      imports: [
        FormsModule,
        NoopAnimationsModule,
        MatFormFieldModule,
        MatInputModule,
        MatSelectModule,
        MatDatepickerModule,
        MatNativeDateModule
      ],
      providers: [
        { provide: FileService, useValue: fileServiceMock },
        { provide: MatSnackBar, useValue: snackBarMock },
        { provide: Router, useValue: routerMock },
        { provide: MatDialog, useValue: dialogMock }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(FileManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create and expose status options', () => {
    expect(component).toBeTruthy();
    expect(component.fileStatusOptions).toContain('ARCHIVED');
    expect(component.fileStatusOptions).toContain('DELETED');
  });

  it('should keep DELETED files when backend returns them', () => {
    fileServiceMock.searchFiles.calls.reset();
    fileServiceMock.searchFiles.and.returnValue(of({
      data: [
        makeFiles(1)[0],
        { ...makeFiles(2)[1], fileId: 999, status: 'DELETED' }
      ]
    }));

    component.searchFiles();

    expect(component.allFiles.length).toBe(2);
    expect(component.allFiles.some(f => (f.status || '').toUpperCase() === 'DELETED')).toBeTrue();
    expect(component.totalElements).toBe(2);
  });

  it('should call searchFiles on init', () => {
    const spy = spyOn(component, 'searchFiles').and.callThrough();
    component.ngOnInit();
    expect(spy).toHaveBeenCalled();
  });

  ignoreTest('should return true for end-date-required when start exists but end is missing', () => {
    component.searchCriteria.startDate = new Date();
    component.searchCriteria.endDate = null;
    expect(component.isEndDateRequired).toBeTrue();
  });

  ignoreTest('should stop search silently when only one date is provided', () => {
    fileServiceMock.searchFiles.calls.reset();
    component.searchCriteria.startDate = new Date('2026-01-01');
    component.searchCriteria.endDate = null;

    component.searchFiles();

    expect(fileServiceMock.searchFiles).not.toHaveBeenCalled();
    expect(component.loading).toBeFalse();
  });

  it('should stop search when end date is before start date', () => {
    fileServiceMock.searchFiles.calls.reset();
    component.searchCriteria.startDate = new Date('2026-01-10');
    component.searchCriteria.endDate = new Date('2026-01-05');

    component.searchFiles();

    expect(fileServiceMock.searchFiles).not.toHaveBeenCalled();
    expect(snackBarMock.open).toHaveBeenCalledWith('End date must be on or after start date.', 'Close', {
      duration: 2600,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast']
    });
  });

  it('should build request, fetch files, and paginate first page on successful search', () => {
    fileServiceMock.searchFiles.calls.reset();
    component.searchCriteria.fileId = 9;
    component.searchCriteria.filename = '  abc.csv  ';
    component.searchCriteria.status = 'FAILED';
    component.searchCriteria.startDate = new Date('2026-01-02T10:00:00');
    component.searchCriteria.endDate = new Date('2026-01-04T10:00:00');

    component.searchFiles();

    const args = fileServiceMock.searchFiles.calls.mostRecent().args[0];
    expect(args.fileId).toBe(9);
    expect(args.filename).toBe('abc.csv');
    expect(args.status).toBe('FAILED');
  expect(args.startDate).toBe((component as any).toStartOfDayIso(component.searchCriteria.startDate));
  expect(args.endDate).toBe((component as any).toEndOfDayIso(component.searchCriteria.endDate));

    expect(component.totalElements).toBe(12);
    expect(component.files.length).toBe(10);
    expect(component.currentPage).toBe(0);
    expect(component.loading).toBeFalse();
  });

  it('should handle search error by clearing rows and showing snackbar', () => {
    fileServiceMock.searchFiles.and.returnValue(throwError(() => new Error('x')));
    component.allFiles = makeFiles(2);
    component.files = makeFiles(2);
    component.totalElements = 2;

    component.searchFiles();

    expect(component.allFiles).toEqual([]);
    expect(component.files).toEqual([]);
    expect(component.totalElements).toBe(0);
    expect(snackBarMock.open).toHaveBeenCalledWith('Failed to load files', 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  });

  ignoreTest('should reset criteria in clearSearch and re-run search', () => {
    const spy = spyOn(component, 'searchFiles').and.callThrough();

    component.searchCriteria.fileId = 1;
    component.searchCriteria.filename = 'x';
    component.searchCriteria.status = 'FAILED';
    component.searchCriteria.startDate = new Date();
    component.searchCriteria.endDate = new Date();

    component.clearSearch();

    expect(component.searchCriteria.fileId).toBeNull();
    expect(component.searchCriteria.filename).toBe('');
    expect(component.searchCriteria.status).toBe('');
    expect(component.searchCriteria.startDate).toBeNull();
    expect(component.searchCriteria.endDate).toBeNull();
    expect(spy).toHaveBeenCalled();
  });

  it('should update visible rows when paginator page changes', () => {
    component.allFiles = makeFiles(12);
    component.pageSize = 10;

    component.onPageChange({ pageIndex: 1, pageSize: 10, length: 12 } as any);

    expect(component.currentPage).toBe(1);
    expect(component.files.length).toBe(2);
    expect(component.files[0].fileId).toBe(11);
  });

  it('should update non-archived status and refresh data', () => {
    const spy = spyOn(component, 'searchFiles').and.callThrough();

    component.updateStatus(7, 'PROCESSING');

    expect(fileServiceMock.updateStatus).toHaveBeenCalledWith(7, 'PROCESSING');
    expect(snackBarMock.open).toHaveBeenCalledWith('Status updated', 'Close', {
      duration: 2600,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-success']
    });
    expect(spy).toHaveBeenCalled();
  });

  ignoreTest('should update ARCHIVED status through updateStatus API', () => {
    component.updateStatus(7, 'ARCHIVED');

    expect(fileServiceMock.updateStatus).toHaveBeenCalledWith(7, 'ARCHIVED');
  });

  it('should show error toast when updateStatus fails', () => {
    fileServiceMock.updateStatus.and.returnValue(throwError(() => new Error('x')));

    component.updateStatus(7, 'PROCESSING');

    expect(snackBarMock.open).toHaveBeenCalledWith('Failed to update status', 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  });

  ignoreTest('should not archive when confirm dialog returns false', () => {
    dialogMock.open.and.returnValue({ afterClosed: () => of(false) });

    component.archiveFile(4);

    expect(fileServiceMock.archiveFile).not.toHaveBeenCalled();
  });

  it('should archive when confirmed and refresh data', () => {
    const spy = spyOn(component, 'searchFiles').and.callThrough();
    dialogMock.open.and.returnValue({ afterClosed: () => of(true) });

    component.archiveFile(4);

    expect(fileServiceMock.archiveFile).toHaveBeenCalledWith(4);
    expect(snackBarMock.open).toHaveBeenCalledWith('File archived', 'Close', {
      duration: 2600,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-success']
    });
    expect(spy).toHaveBeenCalled();
  });

  ignoreTest('should show error toast when archive fails', () => {
    dialogMock.open.and.returnValue({ afterClosed: () => of(true) });
    fileServiceMock.archiveFile.and.returnValue(throwError(() => new Error('x')));

    component.archiveFile(4);

    expect(snackBarMock.open).toHaveBeenCalledWith('Failed to archive file', 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  });

  ignoreTest('should delete when confirmed and refresh', () => {
    const spy = spyOn(component, 'searchFiles').and.callThrough();
    dialogMock.open.and.returnValue({ afterClosed: () => of(true) });

    component.deleteFile(5);

    expect(fileServiceMock.deleteFile).toHaveBeenCalledWith(5);
    expect(snackBarMock.open).toHaveBeenCalledWith('File deleted', 'Close', {
      duration: 2600,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-success']
    });
    expect(spy).toHaveBeenCalled();
  });

  it('should show error toast when delete fails', () => {
    dialogMock.open.and.returnValue({ afterClosed: () => of(true) });
    fileServiceMock.deleteFile.and.returnValue(throwError(() => new Error('x')));

    component.deleteFile(5);

    expect(snackBarMock.open).toHaveBeenCalledWith('Failed to delete file', 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  });

  ignoreTest('should map status classes and format file id correctly', () => {
    expect(component.getStatusClass('COMPLETED')).toBe('status-completed');
    expect(component.getStatusClass('PROCESSING')).toBe('status-processing');
    expect(component.getStatusClass('FAILED')).toBe('status-failed');
    expect(component.getStatusClass('ARCHIVED')).toBe('status-archived');
    expect(component.getStatusClass('UNKNOWN')).toBe('status-processing');

    const formatted = component.formatFileId(12);
    expect(formatted).toMatch(/^FL-\d{4}-00012$/);
  });

  ignoreTest('should map COMPLETED_WITH_ERROR to PARTIALLY_COMPLETED in label', () => {
    expect(component.getStatusLabel('COMPLETED_WITH_ERROR')).toBe('PARTIALLY_COMPLETED');
    expect(component.getStatusLabel('FAILED')).toBe('FAILED');
  });

  ignoreTest('should navigate to file details from viewFile', () => {
    component.viewFile(makeFiles(1)[0]);
    expect(routerMock.navigate).toHaveBeenCalledWith(['/files', 1]);
  });
});
