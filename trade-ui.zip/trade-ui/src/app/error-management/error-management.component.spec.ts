/// <reference types="jasmine" />

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { of, throwError } from 'rxjs';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';

import { ErrorManagementComponent } from './error-management.component';
import { ErrorService } from '../shared/services/error.service';
import { MatSnackBar } from '@angular/material/snack-bar';

import { TransactionError } from '../shared/models/models';

const ignoreTest = (..._args: any[]) => undefined;

describe('ErrorManagementComponent', () => {
  let fixture: ComponentFixture<ErrorManagementComponent>;
  let component: ErrorManagementComponent;

  let errorServiceMock: { searchErrors: jasmine.Spy };
  let snackBarMock: { open: jasmine.Spy };

  const makeErrors = (count: number): TransactionError[] =>
    Array.from({ length: count }, (_, idx) => ({
      errorId: idx + 1,
      fileId: 100 + idx,
      transactionId: `TX-${idx + 1}`,
      accountNumber: `ACC-${idx + 1}`,
      errorField: 'status',
      errorMessage: 'Invalid value',
      status: 'FAILED'
    }));

  beforeEach(async () => {
    errorServiceMock = {
      searchErrors: jasmine.createSpy('searchErrors').and.returnValue(of({ data: makeErrors(12) }))
    };

    snackBarMock = {
      open: jasmine.createSpy('open')
    };

    await TestBed.configureTestingModule({
      declarations: [ErrorManagementComponent],
      imports: [
        FormsModule,
        NoopAnimationsModule,
        MatFormFieldModule,
        MatInputModule,
        MatSelectModule
      ],
      providers: [
        { provide: ErrorService, useValue: errorServiceMock },
        { provide: MatSnackBar, useValue: snackBarMock }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(ErrorManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  ignoreTest('should create and include Duplicate in status options', () => {
    expect(component).toBeTruthy();
    expect(component.errorStatusOptions).toContain('DUPLICATE');
  });

  it('should call searchErrors on init', () => {
    const spy = spyOn(component, 'searchErrors').and.callThrough();
    component.ngOnInit();
    expect(spy).toHaveBeenCalled();
  });

  it('should build search params and paginate first page on successful search', () => {
    component.searchFileId = 45;
    component.searchAccount = 'ACC-99';
    component.searchField = 'status';
    component.searchStatus = 'FAILED';

    component.searchErrors();

    expect(errorServiceMock.searchErrors).toHaveBeenCalledWith({
      fileId: 45,
      accountNumber: 'ACC-99',
      errorField: 'status',
      status: 'FAILED'
    });
    expect(component.totalElements).toBe(12);
    expect(component.errors.length).toBe(10);
    expect(component.currentPage).toBe(0);
    expect(component.loading).toBeFalse();
  });

  it('should update page slice on paginator change', () => {
    component.allErrors = makeErrors(12);
    component.pageSize = 10;

    component.onPageChange({ pageIndex: 1, pageSize: 10, length: 12 } as any);

    expect(component.currentPage).toBe(1);
    expect(component.errors.length).toBe(2);
    expect(component.errors[0].errorId).toBe(11);
  });

  it('should clear filters and trigger a new search', () => {
    const spy = spyOn(component, 'searchErrors').and.callThrough();

    component.searchFileId = 1;
    component.searchAccount = 'A';
    component.searchField = 'f';
    component.searchStatus = 'FAILED';
    component.currentPage = 3;

    component.clearSearch();

    expect(component.searchFileId).toBeNull();
    expect(component.searchAccount).toBe('');
    expect(component.searchField).toBe('');
    expect(component.searchStatus).toBe('');
    expect(component.currentPage).toBe(0);
    expect(spy).toHaveBeenCalled();
  });

  it('should reset data and show snackbar on service failure', () => {
    errorServiceMock.searchErrors.and.returnValue(throwError(() => new Error('x')));
    component.allErrors = makeErrors(2);
    component.errors = makeErrors(2);
    component.totalElements = 2;

    component.searchErrors();

    expect(component.allErrors).toEqual([]);
    expect(component.errors).toEqual([]);
    expect(component.totalElements).toBe(0);
    expect(component.loading).toBeFalse();
    expect(snackBarMock.open).toHaveBeenCalledWith('Failed to load errors', 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  });

  ignoreTest('should extract errors from paged response shape (data.content)', () => {
    errorServiceMock.searchErrors.and.returnValue(of({ data: { content: makeErrors(3) } }));

    component.searchErrors();

    expect(component.totalElements).toBe(3);
    expect(component.errors.length).toBe(3);
  });

  it('should show access denied message on 403 error', () => {
    errorServiceMock.searchErrors.and.returnValue(throwError(() => ({ status: 403 })));

    component.searchErrors();

    expect(snackBarMock.open).toHaveBeenCalledWith(
      'Access denied (403). You do not have permission to view error logs.',
      'Close',
      {
        duration: 3200,
        verticalPosition: 'top',
        horizontalPosition: 'center',
        panelClass: ['app-toast', 'app-toast-error']
      }
    );
  });

  it('should map id to errorId and fallback to 0 when both are missing', () => {
    errorServiceMock.searchErrors.and.returnValue(
      of({
        data: [
          {
            id: 9,
            fileId: 201,
            transactionId: 'T-9',
            accountNumber: 'A-9',
            errorField: 'field',
            errorMessage: 'msg',
            status: 'FAILED'
          },
          {
            fileId: 202,
            transactionId: 'T-0',
            accountNumber: 'A-0',
            errorField: 'field',
            errorMessage: 'msg',
            status: 'FAILED'
          }
        ]
      })
    );

    component.searchErrors();

    expect(component.totalElements).toBe(2);
    expect(component.allErrors[0].errorId).toBe(9);
    expect(component.allErrors[1].errorId).toBe(0);
  });
});
