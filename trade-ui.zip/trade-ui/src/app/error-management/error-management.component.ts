import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ErrorService } from '../shared/services/error.service';
import { TransactionError } from '../shared/models/models';

@Component({
  selector: 'app-error-management',
  templateUrl: './error-management.component.html',
  styleUrls: ['./error-management.component.css']
})
export class ErrorManagementComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  readonly errorStatusOptions = Array.from(new Set(['FAILED', 'RESOLVED', 'DUPLICATE']));

  allErrors: TransactionError[] = [];
  errors: TransactionError[] = [];
  loading = false;
  displayedColumns = ['errorId', 'fileId', 'transactionId', 'accountNumber',
                       'errorField', 'errorMessage', 'status'];

  searchFileId: number | null = null;
  searchAccount = '';
  searchField = '';
  searchStatus = '';

  totalElements = 0;
  pageSize = 10;
  currentPage = 0;

  constructor(
    private errorService: ErrorService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.searchErrors();
  }

  searchErrors(): void {
    this.loading = true;
    this.currentPage = 0;

    const params: any = {
      // Fetch filtered dataset and paginate client-side in table.
    };
    if (this.searchFileId) params.fileId = this.searchFileId;
    if (this.searchAccount) params.accountNumber = this.searchAccount;
  if (this.searchField) params.errorField = this.searchField;
    if (this.searchStatus) params.status = this.searchStatus;

    this.errorService.searchErrors(params).subscribe({
      next: (res: any) => {
        this.allErrors = this.extractErrors(res)
          .sort((a, b) => (b.errorId || 0) - (a.errorId || 0));
        this.totalElements = this.allErrors.length;
        this.applyPagination();
        this.loading = false;
      },
      error: (err: any) => {
        this.allErrors = [];
        this.errors = [];
        this.totalElements = 0;
        this.loading = false;
        if (err?.status === 403) {
          this.showErrorToast('Access denied (403). You do not have permission to view error logs.');
          return;
        }

        this.showErrorToast('Failed to load errors');
      }
    });
  }

  clearSearch(): void {
    this.searchFileId = null;
    this.searchAccount = '';
  this.searchField = '';
    this.searchStatus = '';
    this.currentPage = 0;
    this.searchErrors();
  }

  onPageChange(event: PageEvent): void {
    this.currentPage = event.pageIndex;
    this.pageSize = event.pageSize;
    this.applyPagination();
  }

  private applyPagination(): void {
    const start = this.currentPage * this.pageSize;
    const end = start + this.pageSize;
    this.errors = this.allErrors.slice(start, end);
  }

  private extractErrors(response: any): TransactionError[] {
    const payload = response?.data;
    const list = Array.isArray(payload)
      ? payload
      : Array.isArray(payload?.content)
        ? payload.content
        : [];

    return list.map((item: TransactionError & { id?: number }) => ({
      ...item,
      errorId: item.errorId ?? item.id ?? 0
    }));
  }

  private showErrorToast(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 3200,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['app-toast', 'app-toast-error']
    });
  }
}
