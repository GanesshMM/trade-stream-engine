import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent {
  readonly problemStatementPoints: string[] = [
    'Trade operations teams receive high-volume files with strict turnaround expectations.',
    'Manual validation and fragmented tracking increase operational risk and delay processing.',
    'Without centralized visibility, it is difficult to monitor processing status and error trends in real time.'
  ];

  readonly platformOverviewPoints: string[] = [
    'Trade Stream Engine is a centralized web platform for secure trade-file intake, processing visibility, and lifecycle actions.',
    'It provides a single operational workflow from upload to status tracking, error handling, archive, and delete operations.',
    'The application is built to support reliability, traceability, and faster operational decisions.'
  ];

  readonly operationFeatures: string[] = [
    'Secure authentication and JWT-based API authorization.',
    'CSV upload with drag-and-drop support, file-type validation, and upload status feedback.',
    'Dashboard monitoring with key metrics and latest file activity.',
    'File Load Records search and filtering by file ID, filename, status, and date range.',
    'Operational actions such as view, archive, delete, and status updates with confirmation dialogs.',
    'Error Management with transaction-level filtering and paginated exception visibility.'
  ];

  readonly platformSpecifications: string[] = [
    'Frontend: Angular + Angular Material UI for responsive enterprise workflows.',
    'Data model includes file ID, filename, upload time, record totals, success count, error count, and status.',
  'Supports lifecycle states such as STARTED, PROCESSING, COMPLETED, PARTIALLY_COMPLETED, FAILED, ARCHIVED, and DELETED.',
    'Consistent in-app popup notifications for success, info, and error outcomes.',
    
  ];
}
